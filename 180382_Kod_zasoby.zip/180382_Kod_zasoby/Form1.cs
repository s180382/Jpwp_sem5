using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;


using System.Windows.Forms;


namespace JPWP_Projekt_sem_5
{
    public partial class Form1 : Form
    {


        public Form1()
        {

            InitializeComponent();

        }


        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;  // Turn on WS_EX_COMPOSITED
                return cp;
            }
        }


        Random rnd = new Random();



        int punkty = 0;



        private void Spawn_Trash()
        {



            PictureBox[] items = { plastiki1, plastiki2, plastiki3, plastiki4, plastiki5, plastiki6, plastiki7, plastiki8, plastiki9, plastiki10, plastiki11, plastiki12,plastiki13,
                 plastiki14,plastiki15,plastiki16,plastiki17,plastiki18,plastiki19,plastiki20,plastiki21,plastiki22,plastiki23,plastiki24,plastiki25,plastiki26,plastiki27,plastiki28,
                plastiki29,plastiki30,plastiki31,plastiki32,plastiki33,plastiki34,plastiki35,plastiki36,plastiki37,plastiki38,plastiki39,plastiki40,plastiki41,plastiki42,plastiki43,plastiki44,
                plastiki45,plastiki46,plastiki47,plastiki48,plastiki49,plastiki50,plastiki51,plastiki52,plastiki53,plastiki54,plastiki55,plastiki56,plastiki57,plastiki58,plastiki59,plastiki60,plastiki61,plastiki62,
                plastiki63,organiczne1, organiczne2, organiczne3, organiczne4, organiczne5, organiczne6, organiczne7, organiczne8, organiczne9, organiczne10, organiczne11, organiczne12,organiczne13,
                 organiczne14,organiczne15,organiczne16,organiczne17,organiczne18,organiczne19,organiczne20,organiczne21,organiczne22,organiczne23,organiczne24,organiczne25,organiczne26,organiczne27,organiczne28,
                organiczne29,organiczne30,organiczne31,organiczne32,organiczne33,organiczne34,organiczne35,organiczne36,organiczne37,organiczne38,organiczne39,organiczne40,organiczne41,organiczne42,organiczne43,organiczne44,
                organiczne45,organiczne46,organiczne47,organiczne48,organiczne49,organiczne50,organiczne51,organiczne52,organiczne53,organiczne54,organiczne55,organiczne56,organiczne57,organiczne58,organiczne59,organiczne60,organiczne61,organiczne62,
                organiczne63,papier1, papier2, papier3, papier4, papier5, papier6, papier7, papier8, papier9, papier10, papier11, papier12,papier13,
                 papier14,papier15,papier16,papier17,papier18,papier19,papier20,papier21,papier22,papier23,papier24,papier25,papier26,papier27,papier28,
                papier29,papier30,papier31,papier32,papier33,papier34,papier35,papier36,papier37,papier38,papier39,papier40,papier41,papier42,papier43,papier44,
                papier45,papier46,papier47,papier48,papier49,papier50,papier51,papier52,papier53,papier54,papier55,papier56,papier57,papier58,papier59,papier60,papier61,papier62,
                papier63,szklo1, szklo2, szklo3, szklo4, szklo5, szklo6, szklo7, szklo8, szklo9, szklo10, szklo11, szklo12,szklo13,
                 szklo14,szklo15,szklo16,szklo17,szklo18,szklo19,szklo20,szklo21,szklo22,szklo23,szklo24,szklo25,szklo26,szklo27,szklo28,
                szklo29,szklo30,szklo31,szklo32,szklo33,szklo34,szklo35,szklo36,szklo37,szklo38,szklo39,szklo40,szklo41,szklo42,szklo43,szklo44,
                szklo45,szklo46,szklo47,szklo48,szklo49,szklo50,szklo51,szklo52,szklo53,szklo54,szklo55,szklo56,szklo57,szklo58,szklo59,szklo60,szklo61,szklo62,
                szklo63







            };


            int randnum = rnd.Next(0,251);
            PictureBox PicBox = items[randnum];

            int x = rnd.Next(10, 1280 - PicBox.Width);
            int y = rnd.Next(600 , 760 );

            PicBox.Location = new Point(x, y);


            this.Controls.Add(PicBox);


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Controls.Remove(papier1);
            this.Controls.Remove(papier2);
            this.Controls.Remove(papier3);
            this.Controls.Remove(papier4);
            this.Controls.Remove(papier5);
            this.Controls.Remove(papier6);
            this.Controls.Remove(papier7);
            this.Controls.Remove(papier8);
            this.Controls.Remove(papier9);
            this.Controls.Remove(papier10);
            this.Controls.Remove(papier11);
            this.Controls.Remove(papier12);
            this.Controls.Remove(papier13);
            this.Controls.Remove(papier14);
            this.Controls.Remove(papier15);
            this.Controls.Remove(papier16);
            this.Controls.Remove(papier17);
            this.Controls.Remove(papier18);
            this.Controls.Remove(papier19);
            this.Controls.Remove(papier20);
            this.Controls.Remove(papier21);
            this.Controls.Remove(papier22);
            this.Controls.Remove(papier23);
            this.Controls.Remove(papier24);
            this.Controls.Remove(papier25);
            this.Controls.Remove(papier26);
            this.Controls.Remove(papier27);
            this.Controls.Remove(papier28);
            this.Controls.Remove(papier29);
            this.Controls.Remove(papier30);
            this.Controls.Remove(papier31);
            this.Controls.Remove(papier32);
            this.Controls.Remove(papier33);
            this.Controls.Remove(papier34);
            this.Controls.Remove(papier35);
            this.Controls.Remove(papier36);
            this.Controls.Remove(papier37);
            this.Controls.Remove(papier38);
            this.Controls.Remove(papier39);
            this.Controls.Remove(papier40);
            this.Controls.Remove(papier41);
            this.Controls.Remove(papier42);
            this.Controls.Remove(papier43);
            this.Controls.Remove(papier44);
            this.Controls.Remove(papier45);
            this.Controls.Remove(papier46);
            this.Controls.Remove(papier47);
            this.Controls.Remove(papier48);
            this.Controls.Remove(papier49);
            this.Controls.Remove(papier50);
            this.Controls.Remove(papier51);
            this.Controls.Remove(papier52);
            this.Controls.Remove(papier53);
            this.Controls.Remove(papier54);
            this.Controls.Remove(papier55);
            this.Controls.Remove(papier56);
            this.Controls.Remove(papier57);
            this.Controls.Remove(papier58);
            this.Controls.Remove(papier59);
            this.Controls.Remove(papier60);
            this.Controls.Remove(papier61);
            this.Controls.Remove(papier62);
            this.Controls.Remove(papier63);


            this.Controls.Remove(szklo1);
            this.Controls.Remove(szklo2);
            this.Controls.Remove(szklo3);
            this.Controls.Remove(szklo4);
            this.Controls.Remove(szklo5);
            this.Controls.Remove(szklo6);
            this.Controls.Remove(szklo7);
            this.Controls.Remove(szklo8);
            this.Controls.Remove(szklo9);
            this.Controls.Remove(szklo10);
            this.Controls.Remove(szklo11);
            this.Controls.Remove(szklo12);
            this.Controls.Remove(szklo13);
            this.Controls.Remove(szklo14);
            this.Controls.Remove(szklo15);
            this.Controls.Remove(szklo16);
            this.Controls.Remove(szklo17);
            this.Controls.Remove(szklo18);
            this.Controls.Remove(szklo19);
            this.Controls.Remove(szklo20);
            this.Controls.Remove(szklo21);
            this.Controls.Remove(szklo22);
            this.Controls.Remove(szklo23);
            this.Controls.Remove(szklo24);
            this.Controls.Remove(szklo25);
            this.Controls.Remove(szklo26);
            this.Controls.Remove(szklo27);
            this.Controls.Remove(szklo28);
            this.Controls.Remove(szklo29);
            this.Controls.Remove(szklo30);
            this.Controls.Remove(szklo31);
            this.Controls.Remove(szklo32);
            this.Controls.Remove(szklo33);
            this.Controls.Remove(szklo34);
            this.Controls.Remove(szklo35);
            this.Controls.Remove(szklo36);
            this.Controls.Remove(szklo37);
            this.Controls.Remove(szklo38);
            this.Controls.Remove(szklo39);
            this.Controls.Remove(szklo40);
            this.Controls.Remove(szklo41);
            this.Controls.Remove(szklo42);
            this.Controls.Remove(szklo43);
            this.Controls.Remove(szklo44);
            this.Controls.Remove(szklo45);
            this.Controls.Remove(szklo46);
            this.Controls.Remove(szklo47);
            this.Controls.Remove(szklo48);
            this.Controls.Remove(szklo49);
            this.Controls.Remove(szklo50);
            this.Controls.Remove(szklo51);
            this.Controls.Remove(szklo52);
            this.Controls.Remove(szklo53);
            this.Controls.Remove(szklo54);
            this.Controls.Remove(szklo55);
            this.Controls.Remove(szklo56);
            this.Controls.Remove(szklo57);
            this.Controls.Remove(szklo58);
            this.Controls.Remove(szklo59);
            this.Controls.Remove(szklo60);
            this.Controls.Remove(szklo61);
            this.Controls.Remove(szklo62);
            this.Controls.Remove(szklo63);

            this.Controls.Remove(organiczne1);
            this.Controls.Remove(organiczne2);
            this.Controls.Remove(organiczne3);
            this.Controls.Remove(organiczne4);
            this.Controls.Remove(organiczne5);
            this.Controls.Remove(organiczne6);
            this.Controls.Remove(organiczne7);
            this.Controls.Remove(organiczne8);
            this.Controls.Remove(organiczne9);
            this.Controls.Remove(organiczne10);
            this.Controls.Remove(organiczne11);
            this.Controls.Remove(organiczne12);
            this.Controls.Remove(organiczne13);
            this.Controls.Remove(organiczne14);
            this.Controls.Remove(organiczne15);
            this.Controls.Remove(organiczne16);
            this.Controls.Remove(organiczne17);
            this.Controls.Remove(organiczne18);
            this.Controls.Remove(organiczne19);
            this.Controls.Remove(organiczne20);
            this.Controls.Remove(organiczne21);
            this.Controls.Remove(organiczne22);
            this.Controls.Remove(organiczne23);
            this.Controls.Remove(organiczne24);
            this.Controls.Remove(organiczne25);
            this.Controls.Remove(organiczne26);
            this.Controls.Remove(organiczne27);
            this.Controls.Remove(organiczne28);
            this.Controls.Remove(organiczne29);
            this.Controls.Remove(organiczne30);
            this.Controls.Remove(organiczne31);
            this.Controls.Remove(organiczne32);
            this.Controls.Remove(organiczne33);
            this.Controls.Remove(organiczne34);
            this.Controls.Remove(organiczne35);
            this.Controls.Remove(organiczne36);
            this.Controls.Remove(organiczne37);
            this.Controls.Remove(organiczne38);
            this.Controls.Remove(organiczne39);
            this.Controls.Remove(organiczne40);
            this.Controls.Remove(organiczne41);
            this.Controls.Remove(organiczne42);
            this.Controls.Remove(organiczne43);
            this.Controls.Remove(organiczne44);
            this.Controls.Remove(organiczne45);
            this.Controls.Remove(organiczne46);
            this.Controls.Remove(organiczne47);
            this.Controls.Remove(organiczne48);
            this.Controls.Remove(organiczne49);
            this.Controls.Remove(organiczne50);
            this.Controls.Remove(organiczne51);
            this.Controls.Remove(organiczne52);
            this.Controls.Remove(organiczne53);
            this.Controls.Remove(organiczne54);
            this.Controls.Remove(organiczne55);
            this.Controls.Remove(organiczne56);
            this.Controls.Remove(organiczne57);
            this.Controls.Remove(organiczne58);
            this.Controls.Remove(organiczne59);
            this.Controls.Remove(organiczne60);
            this.Controls.Remove(organiczne61);
            this.Controls.Remove(organiczne62);
            this.Controls.Remove(organiczne63);





            this.Controls.Remove(plastiki1);
            this.Controls.Remove(plastiki2);
            this.Controls.Remove(plastiki3);
            this.Controls.Remove(plastiki4);
            this.Controls.Remove(plastiki5);
            this.Controls.Remove(plastiki6);
            this.Controls.Remove(plastiki7);
            this.Controls.Remove(plastiki8);
            this.Controls.Remove(plastiki9);
            this.Controls.Remove(plastiki10);
            this.Controls.Remove(plastiki11);
            this.Controls.Remove(plastiki12);
            this.Controls.Remove(plastiki13);
            this.Controls.Remove(plastiki14);
            this.Controls.Remove(plastiki15);
            this.Controls.Remove(plastiki16);
            this.Controls.Remove(plastiki17);
            this.Controls.Remove(plastiki18);
            this.Controls.Remove(plastiki19);
            this.Controls.Remove(plastiki20);
            this.Controls.Remove(plastiki21);
            this.Controls.Remove(plastiki22);
            this.Controls.Remove(plastiki23);
            this.Controls.Remove(plastiki24);
            this.Controls.Remove(plastiki25);
            this.Controls.Remove(plastiki26);
            this.Controls.Remove(plastiki27);
            this.Controls.Remove(plastiki28);
            this.Controls.Remove(plastiki29);
            this.Controls.Remove(plastiki30);
            this.Controls.Remove(plastiki31);
            this.Controls.Remove(plastiki32);
            this.Controls.Remove(plastiki33);
            this.Controls.Remove(plastiki34);
            this.Controls.Remove(plastiki35);
            this.Controls.Remove(plastiki36);
            this.Controls.Remove(plastiki37);
            this.Controls.Remove(plastiki38);
            this.Controls.Remove(plastiki39);
            this.Controls.Remove(plastiki40);
            this.Controls.Remove(plastiki41);
            this.Controls.Remove(plastiki42);
            this.Controls.Remove(plastiki43);
            this.Controls.Remove(plastiki44);
            this.Controls.Remove(plastiki45);
            this.Controls.Remove(plastiki46);
            this.Controls.Remove(plastiki47);
            this.Controls.Remove(plastiki48);
            this.Controls.Remove(plastiki49);
            this.Controls.Remove(plastiki50);
            this.Controls.Remove(plastiki51);
            this.Controls.Remove(plastiki52);
            this.Controls.Remove(plastiki53);
            this.Controls.Remove(plastiki54);
            this.Controls.Remove(plastiki55);
            this.Controls.Remove(plastiki56);
            this.Controls.Remove(plastiki57);
            this.Controls.Remove(plastiki58);
            this.Controls.Remove(plastiki59);
            this.Controls.Remove(plastiki60);
            this.Controls.Remove(plastiki61);
            this.Controls.Remove(plastiki62);
            this.Controls.Remove(plastiki63);












            ;


































        }



        private void TimerEvent(object sender, EventArgs e)
        {

            Spawn_Trash();

        }


        private void papier1_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier1.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier1);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;

                    }
                   
                    
                   

                }

                

            }
        }

        private void papier2_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier2.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier2);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                    

                }

            }
        }

        private void papier3_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier3.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier3);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                   
                }
               

            }
        }

        private void plastiki1_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki1.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki1);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                   
                }
               

            }
        }

        private void plastiki2_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki2.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki2);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                   
                }
               

            }
        }

        private void plastiki3_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki3.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki3);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }

               
            }
        }
        private void plastiki4_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki4.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki4);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
              

            }
        }
        private void plastiki7_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki7.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki7);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                    
                }
                

            }
        }
        private void plastiki10_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki10.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki10);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                


            }
        }
        private void plastiki13_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki13.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki13);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                   
                }
                
            }
        }
        private void plastiki16_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki16.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki16);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               


            }
        }
        private void plastiki19_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki19.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki19);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               


            }
        }
        private void plastiki22_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki22.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki22);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                


            }
        }
        private void plastiki25_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki25.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki25);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                


            }
        }
        private void plastiki28_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki28.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki28);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               


            }
        }
        private void plastiki31_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki31.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki31);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               


            }
        }
        private void plastiki34_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki34.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki34);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               


            }
        }
        private void plastiki37_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki37.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki37);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki40_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki40.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki40);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               
               

            }
        }
        private void plastiki43_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki43.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki43);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki46_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki46.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki46);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               


            }
        }
        private void plastiki49_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki49.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki49);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
              

            }
        }
        private void plastiki52_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki52.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki52);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               


            }
        }
        private void plastiki55_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki55.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki55);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki58_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki58.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki58);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                
               


            }
        }
        private void plastiki61_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki61.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki61);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                if (x is PictureBox && (string)x.Tag != "object_plastik")
                {
                    if (plastiki61.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki61);
                        punkty = punkty - 1;
                        label1.Text = "Score: " + punkty;

                    }




                }


            }
        }

        private void plastiki5_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki5.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki5);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki8_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki8.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki8);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
              

            }
        }
        private void plastiki11_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki11.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki11);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki14_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki14.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki14);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki17_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki17.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki17);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki20_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki20.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki20);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki23_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki23.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki23);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                
            }
        }
        private void plastiki26_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki26.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki26);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki29_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki29.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki29);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki32_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki32.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki32);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki35_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki35.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki35);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki38_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki38.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki38);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
              
            }
        }
        private void plastiki41_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki41.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki41);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               
            }
        }
        private void plastiki44_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki44.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki44);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki47_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki47.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki47);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
              

            }
        }
        private void plastiki50_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki5.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki50);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki53_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki53.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki53);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki56_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki56.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki56);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki59_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki59.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki59);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
              

            }
        }
        private void plastiki62_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki62.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki62);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }

        private void plastiki6_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki6.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki6);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki9_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki9.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki9);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
              

            }
        }
        private void plastiki12_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki12.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki12);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki15_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki15.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki15);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki18_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki18.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki18);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki21_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki21.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki21);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki24_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki24.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki24);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               
            }
        }
        private void plastiki27_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki27.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki27);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki30_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki30.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki30);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki33_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki33.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki33);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki36_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki36.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki36);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
              
            }
        }
        private void plastiki39_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki39.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki39);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki42_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki42.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki42);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki45_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki45.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki45);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                
            }
        }
        private void plastiki48_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki48.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki48);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
               

            }
        }
        private void plastiki51_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki51.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki51);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                

            }
        }
        private void plastiki54_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki54.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki54);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                if (x is PictureBox && (string)x.Tag != "object_plastik")
                {
                    if (plastiki54.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki54);
                        punkty = punkty - 1;
                        label1.Text = "Score: " + punkty;

                    }




                }

            }
        }
        private void plastiki57_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki57.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki57);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                if (x is PictureBox && (string)x.Tag != "object_plastik")
                {
                    if (plastiki57.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki57);
                        punkty = punkty - 1;
                        label1.Text = "Score: " + punkty;

                    }




                }

            }
        }
        private void plastiki60_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki60.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki60);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                if (x is PictureBox && (string)x.Tag != "object_plastik")
                {
                    if (plastiki60.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki60);
                        punkty = punkty - 1;
                        label1.Text = "Score: " + punkty;

                    }




                }

            }
        }
        private void plastiki63_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_plastik")
                {
                    if (plastiki63.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki63);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }
                }
                if (x is PictureBox && (string)x.Tag != "object_plastik")
                {
                    if (plastiki63.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(plastiki63);
                        punkty = punkty - 1;
                        label1.Text = "Score: " + punkty;

                    }




                }

            }
        }

        private void organiczne1_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne1.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne1);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }

        private void organiczne2_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne2.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne2);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }

        private void organiczne3_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne3.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne3);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }

        private void szklo1_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo1.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo1);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }

        private void szklo2_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo2.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo2);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }

        private void szklo3_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo3.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo3);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne4_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne4.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne4);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne7_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne7.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne7);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne10_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne10.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne10);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne13_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne13.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne13);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne16_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne16.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne16);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne19_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne19.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne19);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne22_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne22.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne22);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne25_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne25.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne25);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne28_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne28.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne28);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne31_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne31.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne31);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne34_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne34.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne34);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne37_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne37.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne37);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne40_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne40.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne40);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne43_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne43.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne43);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne46_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne46.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne46);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne49_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne49.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne49);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne52_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne52.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne52);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne55_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne55.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne55);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne58_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne58.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne58);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne61_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne61.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne61);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne5_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne5.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne5);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne8_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne8.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne8);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne11_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne11.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne11);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne14_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne14.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne14);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne17_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne17.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne17);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne20_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne20.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne20);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne23_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne23.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne23);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne26_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne26.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne26);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne29_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne29.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne29);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne32_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne32.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne32);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne35_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne35.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne35);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne38_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne38.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne38);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne41_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne41.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne41);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne44_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne44.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne44);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne47_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne47.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne47);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne50_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne50.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne50);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne53_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne53.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne53);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne56_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne56.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne56);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne59_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne59.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne59);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne62_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne62.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne62);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne6_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne6.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne6);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne9_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne9.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne9);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne12_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne12.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne12);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne15_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne15.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne15);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne18_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne18.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne18);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne21_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne21.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne21);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne24_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne24.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne24);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne27_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne27.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne27);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne30_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne30.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne30);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne33_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne33.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne33);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne36_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne36.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne36);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne39_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne39.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne39);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne42_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne42.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne42);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne45_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne45.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne45);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne48_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne48.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne48);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne51_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne51.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne51);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne54_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne54.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne54);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne57_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne57.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne57);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne60_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne60.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne60);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void organiczne63_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_organic")
                {
                    if (organiczne63.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(organiczne63);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo4_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo4.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo4);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo7_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo7.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo7);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo10_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo10.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo10);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo13_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo13.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo13);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo16_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo16.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo16);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo19_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo19.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo19);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo22_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo22.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo22);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo25_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo25.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo25);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo28_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo28.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo28);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo31_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo31.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo31);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo34_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo34.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo34);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo37_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo37.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo37);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo40_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo40.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo40);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo43_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo43.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo43);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo46_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo46.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo46);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo49_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo49.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo49);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo52_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo52.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo52);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo55_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo55.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo55);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo58_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo58.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo58);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo61_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo61.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo61);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo5_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo5.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo5);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo8_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo8.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo8);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo11_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo11.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo11);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo14_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo14.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo14);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo17_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo17.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo17);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo20_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo20.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo20);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo23_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo23.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo23);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo26_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo26.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo26);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo29_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo29.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo29);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo32_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo32.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo32);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo35_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo35.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo35);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo38_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo38.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo38);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo41_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo41.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo41);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo44_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo44.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo44);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo47_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo47.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo47);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo50_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo50.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo50);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo53_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo53.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo53);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo56_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo56.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo56);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo59_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo59.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo59);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo62_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo62.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo62);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo6_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo6.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo6);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo9_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo9.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo9);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo12_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo12.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo12);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo15_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo15.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo15);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo18_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo18.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo18);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo21_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo21.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo21);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo24_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo24.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo24);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo27_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo27.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo27);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo30_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo30.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo30);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo33_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo33.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo33);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo36_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo36.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo36);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo39_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo39.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo39);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo42_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo42.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo42);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo45_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo45.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo45);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo48_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo48.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo48);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }
        }
        private void szklo51_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo51.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo51);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }




        }
        private void szklo54_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo54.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo54);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }




        }
        private void szklo57_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo57.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo57);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }




        }
        private void szklo60_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo60.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo60);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }





        }
        private void szklo63_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_glass")
                {
                    if (szklo63.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(szklo63);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }


            }
        }
        private void papier4_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier4.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier4);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }


            }
        }
        private void papier7_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier7.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier7);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }




        }
        private void papier10_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier10.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier10);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }





        }
        private void papier13_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier13.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier13);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }



        }
        private void papier16_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier16.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier16);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier19_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier19.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier19);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier22_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier22.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier22);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier25_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier25.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier25);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier28_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier28.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier28);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier31_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier31.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier31);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier34_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier34.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier34);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier37_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier37.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier37);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier40_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier40.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier40);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier43_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier43.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier43);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier46_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier46.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier46);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier49_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier49.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier49);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier52_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier52.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier52);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier55_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier55.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier55);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier58_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier58.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier58);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
        private void papier61_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier61.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier61);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier5_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier5.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier5);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier8_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier8.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier8);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier11_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier11.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier11);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier14_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier14.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier14);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier17_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier17.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier17);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier20_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier20.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier20);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier23_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier23.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier23);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier26_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier26.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier26);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier29_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier29.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier29);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier32_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier32.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier32);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier35_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier35.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier35);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier38_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier38.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier38);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier41_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier41.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier41);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier44_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier44.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier44);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier47_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier47.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier47);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier50_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier50.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier50);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier53_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier53.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier53);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier56_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier56.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier56);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier59_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier59.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier59);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier62_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier62.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier62);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier6_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier6.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier6);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier9_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier9.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier9);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier12_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier12.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier12);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier15_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier15.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier15);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier18_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier18.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier18);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier21_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier21.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier21);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier24_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier24.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier24);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier27_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier27.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier27);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier30_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier30.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier30);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier33_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier33.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier33);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier36_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier36.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier36);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier39_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier39.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier39);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier42_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier42.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier42);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier45_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier45.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier45);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier48_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier48.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier48);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier51_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier51.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier51);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier54_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier54.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier54);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier57_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier57.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier57);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier60_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier60.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier60);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }
		private void papier63_MouseMove(object sender, MouseEventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "object_papier")
                {
                    if (papier63.Bounds.IntersectsWith(x.Bounds))
                    {
                        this.Controls.Remove(papier63);
                        punkty = punkty + 1;
                        label1.Text = "Score: " + punkty;
                    }

                }

            }

        }




    }

}