﻿



namespace JPWP_Projekt_sem_5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.plastiki1 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki2 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki3 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki4 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki7 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki10 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki13 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki16 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki19 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki22 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki25 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki28 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki31 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki34 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki37 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki40 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki43 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki46 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki49 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki52 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki55 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki58 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki61 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki5 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki8 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki11 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki14 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki17 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki20 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki23 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki26 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki29 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki32 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki35 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki38 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki41 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki44 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki47 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki50 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki53 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki56 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki59 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki62 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.szklo1 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo2 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo3 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.papier1 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier2 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier3 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.organiczne1 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne2 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne3 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.plastiki6 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki9 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki12 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki15 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki18 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki21 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki24 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki27 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki30 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki33 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki36 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki39 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki42 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki45 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki48 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki51 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki54 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki57 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki60 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.plastiki63 = new JPWP_Projekt_sem_5.Plastiki(this.components);
            this.organiczne4 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne7 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne10 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne13 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne16 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne19 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne22 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne25 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne28 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne31 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne34 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne37 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne40 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne43 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne46 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne49 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne52 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne55 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne58 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne61 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne5 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne8 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne11 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne14 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne17 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne20 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne23 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne26 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne29 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne32 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne35 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne38 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne41 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne44 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne47 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne50 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne53 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne56 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne59 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne62 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne6 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne9 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne12 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne15 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne18 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne21 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne24 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne27 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne30 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne33 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne36 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne39 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne42 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne45 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne48 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne51 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne54 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne57 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne60 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.organiczne63 = new JPWP_Projekt_sem_5.Organiczne(this.components);
            this.szklo4 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo7 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo10 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo13 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo16 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo19 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo22 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo25 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo28 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo31 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo34 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo37 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo40 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo43 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo46 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo49 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo52 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo55 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo58 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo61 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo5 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo8 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo11 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo14 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo17 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo20 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo23 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo26 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo29 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo32 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo35 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo38 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo41 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo44 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo47 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo50 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo53 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo56 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo59 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo62 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo6 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo9 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo12 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo15 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo18 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo21 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo24 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo27 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo30 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo33 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo36 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo39 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo42 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo45 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo48 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo51 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo54 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo57 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo60 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.szklo63 = new JPWP_Projekt_sem_5.Szklo(this.components);
            this.papier4 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier7 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier10 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier13 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier16 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier19 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier22 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier25 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier28 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier31 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier34 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier37 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier40 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier43 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier46 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier49 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier52 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier55 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier58 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier61 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier5 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier8 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier11 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier17 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier14 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier20 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier23 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier26 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier29 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier32 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier35 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier38 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier41 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier44 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier47 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier50 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier53 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier56 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier59 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier62 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier6 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier9 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier12 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier15 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier18 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier21 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier24 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier27 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier30 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier33 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier36 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier39 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier42 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier45 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier48 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier51 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier54 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier57 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier60 = new JPWP_Projekt_sem_5.Papier(this.components);
            this.papier63 = new JPWP_Projekt_sem_5.Papier(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier63)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(240, 425);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(115, 146);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "object_papier";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(480, 425);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(115, 146);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "object_plastik";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Location = new System.Drawing.Point(720, 425);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(115, 146);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "object_organic";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.Location = new System.Drawing.Point(960, 425);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(115, 146);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "object_glass";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Impact", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 60);
            this.label1.TabIndex = 16;
            this.label1.Text = "Score: 0";
            // 
            // plastiki1
            // 
            this.plastiki1.BackColor = System.Drawing.Color.Transparent;
            this.plastiki1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki1.BackgroundImage")));
            this.plastiki1.Location = new System.Drawing.Point(349, 652);
            this.plastiki1.Name = "plastiki1";
            this.plastiki1.Size = new System.Drawing.Size(48, 96);
            this.plastiki1.TabIndex = 17;
            this.plastiki1.TabStop = false;
           
            this.plastiki1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki1_MouseMove);
            // 
            // plastiki2
            // 
            this.plastiki2.BackColor = System.Drawing.Color.Transparent;
            this.plastiki2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki2.BackgroundImage")));
            this.plastiki2.Location = new System.Drawing.Point(430, 668);
            this.plastiki2.Name = "plastiki2";
            this.plastiki2.Size = new System.Drawing.Size(45, 80);
            this.plastiki2.TabIndex = 18;
            this.plastiki2.TabStop = false;
           
            this.plastiki2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki2_MouseMove);
            // 
            // plastiki3
            // 
            this.plastiki3.BackColor = System.Drawing.Color.Transparent;
            this.plastiki3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki3.BackgroundImage")));
            this.plastiki3.Location = new System.Drawing.Point(511, 679);
            this.plastiki3.Name = "plastiki3";
            this.plastiki3.Size = new System.Drawing.Size(40, 70);
            this.plastiki3.TabIndex = 19;
            this.plastiki3.TabStop = false;
           
            this.plastiki3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki3_MouseMove);
            // 
            // plastiki4
            // 
            this.plastiki4.BackColor = System.Drawing.Color.Transparent;
            this.plastiki4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki4.BackgroundImage")));
            this.plastiki4.Location = new System.Drawing.Point(349, 652);
            this.plastiki4.Name = "plastiki4";
            this.plastiki4.Size = new System.Drawing.Size(48, 96);
            this.plastiki4.TabIndex = 29;
            this.plastiki4.TabStop = false;
           
            this.plastiki4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki4_MouseMove);
            // 
            // plastiki7
            // 
            this.plastiki7.BackColor = System.Drawing.Color.Transparent;
            this.plastiki7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki7.BackgroundImage")));
            this.plastiki7.Location = new System.Drawing.Point(349, 652);
            this.plastiki7.Name = "plastiki7";
            this.plastiki7.Size = new System.Drawing.Size(48, 96);
            this.plastiki7.TabIndex = 30;
            this.plastiki7.TabStop = false;
         
            this.plastiki7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki7_MouseMove);
            // 
            // plastiki10
            // 
            this.plastiki10.BackColor = System.Drawing.Color.Transparent;
            this.plastiki10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki10.BackgroundImage")));
            this.plastiki10.Location = new System.Drawing.Point(349, 652);
            this.plastiki10.Name = "plastiki10";
            this.plastiki10.Size = new System.Drawing.Size(48, 96);
            this.plastiki10.TabIndex = 31;
            this.plastiki10.TabStop = false;
           
            this.plastiki10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki10_MouseMove);
            // 
            // plastiki13
            // 
            this.plastiki13.BackColor = System.Drawing.Color.Transparent;
            this.plastiki13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki13.BackgroundImage")));
            this.plastiki13.Location = new System.Drawing.Point(349, 652);
            this.plastiki13.Name = "plastiki13";
            this.plastiki13.Size = new System.Drawing.Size(48, 96);
            this.plastiki13.TabIndex = 32;
            this.plastiki13.TabStop = false;
           
            this.plastiki13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki13_MouseMove);
            // 
            // plastiki16
            // 
            this.plastiki16.BackColor = System.Drawing.Color.Transparent;
            this.plastiki16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki16.BackgroundImage")));
            this.plastiki16.Location = new System.Drawing.Point(349, 652);
            this.plastiki16.Name = "plastiki16";
            this.plastiki16.Size = new System.Drawing.Size(48, 96);
            this.plastiki16.TabIndex = 33;
            this.plastiki16.TabStop = false;
        
            this.plastiki16.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki16_MouseMove);
            // 
            // plastiki19
            // 
            this.plastiki19.BackColor = System.Drawing.Color.Transparent;
            this.plastiki19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki19.BackgroundImage")));
            this.plastiki19.Location = new System.Drawing.Point(349, 652);
            this.plastiki19.Name = "plastiki19";
            this.plastiki19.Size = new System.Drawing.Size(48, 96);
            this.plastiki19.TabIndex = 34;
            this.plastiki19.TabStop = false;
         
            this.plastiki19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki19_MouseMove);
            // 
            // plastiki22
            // 
            this.plastiki22.BackColor = System.Drawing.Color.Transparent;
            this.plastiki22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki22.BackgroundImage")));
            this.plastiki22.Location = new System.Drawing.Point(349, 652);
            this.plastiki22.Name = "plastiki22";
            this.plastiki22.Size = new System.Drawing.Size(48, 96);
            this.plastiki22.TabIndex = 35;
            this.plastiki22.TabStop = false;
          
            this.plastiki22.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki22_MouseMove);
            // 
            // plastiki25
            // 
            this.plastiki25.BackColor = System.Drawing.Color.Transparent;
            this.plastiki25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki25.BackgroundImage")));
            this.plastiki25.Location = new System.Drawing.Point(349, 652);
            this.plastiki25.Name = "plastiki25";
            this.plastiki25.Size = new System.Drawing.Size(48, 96);
            this.plastiki25.TabIndex = 36;
            this.plastiki25.TabStop = false;
         
            this.plastiki25.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki25_MouseMove);
            // 
            // plastiki28
            // 
            this.plastiki28.BackColor = System.Drawing.Color.Transparent;
            this.plastiki28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki28.BackgroundImage")));
            this.plastiki28.Location = new System.Drawing.Point(349, 652);
            this.plastiki28.Name = "plastiki28";
            this.plastiki28.Size = new System.Drawing.Size(48, 96);
            this.plastiki28.TabIndex = 37;
            this.plastiki28.TabStop = false;
        
            this.plastiki28.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki28_MouseMove);
            // 
            // plastiki31
            // 
            this.plastiki31.BackColor = System.Drawing.Color.Transparent;
            this.plastiki31.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki31.BackgroundImage")));
            this.plastiki31.Location = new System.Drawing.Point(349, 652);
            this.plastiki31.Name = "plastiki31";
            this.plastiki31.Size = new System.Drawing.Size(48, 96);
            this.plastiki31.TabIndex = 38;
            this.plastiki31.TabStop = false;
         
            this.plastiki31.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki31_MouseMove);
            // 
            // plastiki34
            // 
            this.plastiki34.BackColor = System.Drawing.Color.Transparent;
            this.plastiki34.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki34.BackgroundImage")));
            this.plastiki34.Location = new System.Drawing.Point(349, 652);
            this.plastiki34.Name = "plastiki34";
            this.plastiki34.Size = new System.Drawing.Size(48, 96);
            this.plastiki34.TabIndex = 39;
            this.plastiki34.TabStop = false;
         
            this.plastiki34.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki34_MouseMove);
            // 
            // plastiki37
            // 
            this.plastiki37.BackColor = System.Drawing.Color.Transparent;
            this.plastiki37.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki37.BackgroundImage")));
            this.plastiki37.Location = new System.Drawing.Point(349, 652);
            this.plastiki37.Name = "plastiki37";
            this.plastiki37.Size = new System.Drawing.Size(48, 96);
            this.plastiki37.TabIndex = 40;
            this.plastiki37.TabStop = false;
        
            this.plastiki37.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki37_MouseMove);
            // 
            // plastiki40
            // 
            this.plastiki40.BackColor = System.Drawing.Color.Transparent;
            this.plastiki40.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki40.BackgroundImage")));
            this.plastiki40.Location = new System.Drawing.Point(349, 652);
            this.plastiki40.Name = "plastiki40";
            this.plastiki40.Size = new System.Drawing.Size(48, 96);
            this.plastiki40.TabIndex = 41;
            this.plastiki40.TabStop = false;
        
            this.plastiki40.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki40_MouseMove);
            // 
            // plastiki43
            // 
            this.plastiki43.BackColor = System.Drawing.Color.Transparent;
            this.plastiki43.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki43.BackgroundImage")));
            this.plastiki43.Location = new System.Drawing.Point(349, 652);
            this.plastiki43.Name = "plastiki43";
            this.plastiki43.Size = new System.Drawing.Size(48, 96);
            this.plastiki43.TabIndex = 42;
            this.plastiki43.TabStop = false;
           
            this.plastiki43.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki43_MouseMove);
            // 
            // plastiki46
            // 
            this.plastiki46.BackColor = System.Drawing.Color.Transparent;
            this.plastiki46.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki46.BackgroundImage")));
            this.plastiki46.Location = new System.Drawing.Point(349, 652);
            this.plastiki46.Name = "plastiki46";
            this.plastiki46.Size = new System.Drawing.Size(48, 96);
            this.plastiki46.TabIndex = 43;
            this.plastiki46.TabStop = false;
         
            this.plastiki46.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki46_MouseMove);
            // 
            // plastiki49
            // 
            this.plastiki49.BackColor = System.Drawing.Color.Transparent;
            this.plastiki49.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki49.BackgroundImage")));
            this.plastiki49.Location = new System.Drawing.Point(349, 652);
            this.plastiki49.Name = "plastiki49";
            this.plastiki49.Size = new System.Drawing.Size(48, 96);
            this.plastiki49.TabIndex = 44;
            this.plastiki49.TabStop = false;
          
            this.plastiki49.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki49_MouseMove);
            // 
            // plastiki52
            // 
            this.plastiki52.BackColor = System.Drawing.Color.Transparent;
            this.plastiki52.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki52.BackgroundImage")));
            this.plastiki52.Location = new System.Drawing.Point(349, 652);
            this.plastiki52.Name = "plastiki52";
            this.plastiki52.Size = new System.Drawing.Size(48, 96);
            this.plastiki52.TabIndex = 45;
            this.plastiki52.TabStop = false;
            
            this.plastiki52.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki52_MouseMove);
            // 
            // plastiki55
            // 
            this.plastiki55.BackColor = System.Drawing.Color.Transparent;
            this.plastiki55.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki55.BackgroundImage")));
            this.plastiki55.Location = new System.Drawing.Point(349, 652);
            this.plastiki55.Name = "plastiki55";
            this.plastiki55.Size = new System.Drawing.Size(48, 96);
            this.plastiki55.TabIndex = 46;
            this.plastiki55.TabStop = false;
         
            this.plastiki55.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki55_MouseMove);
            // 
            // plastiki58
            // 
            this.plastiki58.BackColor = System.Drawing.Color.Transparent;
            this.plastiki58.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki58.BackgroundImage")));
            this.plastiki58.Location = new System.Drawing.Point(349, 652);
            this.plastiki58.Name = "plastiki58";
            this.plastiki58.Size = new System.Drawing.Size(48, 96);
            this.plastiki58.TabIndex = 47;
            this.plastiki58.TabStop = false;
           
            this.plastiki58.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki58_MouseMove);
            // 
            // plastiki61
            // 
            this.plastiki61.BackColor = System.Drawing.Color.Transparent;
            this.plastiki61.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki61.BackgroundImage")));
            this.plastiki61.Location = new System.Drawing.Point(349, 652);
            this.plastiki61.Name = "plastiki61";
            this.plastiki61.Size = new System.Drawing.Size(48, 96);
            this.plastiki61.TabIndex = 48;
            this.plastiki61.TabStop = false;
         
            this.plastiki61.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki61_MouseMove);
            // 
            // plastiki5
            // 
            this.plastiki5.BackColor = System.Drawing.Color.Transparent;
            this.plastiki5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki5.BackgroundImage")));
            this.plastiki5.Location = new System.Drawing.Point(430, 668);
            this.plastiki5.Name = "plastiki5";
            this.plastiki5.Size = new System.Drawing.Size(45, 80);
            this.plastiki5.TabIndex = 78;
            this.plastiki5.TabStop = false;
        
            this.plastiki5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki5_MouseMove);
            // 
            // plastiki8
            // 
            this.plastiki8.BackColor = System.Drawing.Color.Transparent;
            this.plastiki8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki8.BackgroundImage")));
            this.plastiki8.Location = new System.Drawing.Point(430, 668);
            this.plastiki8.Name = "plastiki8";
            this.plastiki8.Size = new System.Drawing.Size(45, 80);
            this.plastiki8.TabIndex = 79;
            this.plastiki8.TabStop = false;
          
            this.plastiki8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki8_MouseMove);
            // 
            // plastiki11
            // 
            this.plastiki11.BackColor = System.Drawing.Color.Transparent;
            this.plastiki11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki11.BackgroundImage")));
            this.plastiki11.Location = new System.Drawing.Point(430, 668);
            this.plastiki11.Name = "plastiki11";
            this.plastiki11.Size = new System.Drawing.Size(45, 80);
            this.plastiki11.TabIndex = 80;
            this.plastiki11.TabStop = false;
          
            this.plastiki11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki11_MouseMove);
            // 
            // plastiki14
            // 
            this.plastiki14.BackColor = System.Drawing.Color.Transparent;
            this.plastiki14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki14.BackgroundImage")));
            this.plastiki14.Location = new System.Drawing.Point(430, 668);
            this.plastiki14.Name = "plastiki14";
            this.plastiki14.Size = new System.Drawing.Size(45, 80);
            this.plastiki14.TabIndex = 81;
            this.plastiki14.TabStop = false;
         
            this.plastiki14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki14_MouseMove);
            // 
            // plastiki17
            // 
            this.plastiki17.BackColor = System.Drawing.Color.Transparent;
            this.plastiki17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki17.BackgroundImage")));
            this.plastiki17.Location = new System.Drawing.Point(430, 668);
            this.plastiki17.Name = "plastiki17";
            this.plastiki17.Size = new System.Drawing.Size(45, 80);
            this.plastiki17.TabIndex = 82;
            this.plastiki17.TabStop = false;
          
            this.plastiki17.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki17_MouseMove);
            // 
            // plastiki20
            // 
            this.plastiki20.BackColor = System.Drawing.Color.Transparent;
            this.plastiki20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki20.BackgroundImage")));
            this.plastiki20.Location = new System.Drawing.Point(430, 668);
            this.plastiki20.Name = "plastiki20";
            this.plastiki20.Size = new System.Drawing.Size(45, 80);
            this.plastiki20.TabIndex = 83;
            this.plastiki20.TabStop = false;
        
            this.plastiki20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki20_MouseMove);
            // 
            // plastiki23
            // 
            this.plastiki23.BackColor = System.Drawing.Color.Transparent;
            this.plastiki23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki23.BackgroundImage")));
            this.plastiki23.Location = new System.Drawing.Point(430, 668);
            this.plastiki23.Name = "plastiki23";
            this.plastiki23.Size = new System.Drawing.Size(45, 80);
            this.plastiki23.TabIndex = 84;
            this.plastiki23.TabStop = false;
         
            this.plastiki23.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki23_MouseMove);
            // 
            // plastiki26
            // 
            this.plastiki26.BackColor = System.Drawing.Color.Transparent;
            this.plastiki26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki26.BackgroundImage")));
            this.plastiki26.Location = new System.Drawing.Point(430, 668);
            this.plastiki26.Name = "plastiki26";
            this.plastiki26.Size = new System.Drawing.Size(45, 80);
            this.plastiki26.TabIndex = 85;
            this.plastiki26.TabStop = false;
        
            this.plastiki26.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki26_MouseMove);
            // 
            // plastiki29
            // 
            this.plastiki29.BackColor = System.Drawing.Color.Transparent;
            this.plastiki29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki29.BackgroundImage")));
            this.plastiki29.Location = new System.Drawing.Point(430, 668);
            this.plastiki29.Name = "plastiki29";
            this.plastiki29.Size = new System.Drawing.Size(45, 80);
            this.plastiki29.TabIndex = 86;
            this.plastiki29.TabStop = false;
           
            this.plastiki29.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki29_MouseMove);
            // 
            // plastiki32
            // 
            this.plastiki32.BackColor = System.Drawing.Color.Transparent;
            this.plastiki32.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki32.BackgroundImage")));
            this.plastiki32.Location = new System.Drawing.Point(430, 668);
            this.plastiki32.Name = "plastiki32";
            this.plastiki32.Size = new System.Drawing.Size(45, 80);
            this.plastiki32.TabIndex = 87;
            this.plastiki32.TabStop = false;
        
            this.plastiki32.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki32_MouseMove);
            // 
            // plastiki35
            // 
            this.plastiki35.BackColor = System.Drawing.Color.Transparent;
            this.plastiki35.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki35.BackgroundImage")));
            this.plastiki35.Location = new System.Drawing.Point(430, 668);
            this.plastiki35.Name = "plastiki35";
            this.plastiki35.Size = new System.Drawing.Size(45, 80);
            this.plastiki35.TabIndex = 88;
            this.plastiki35.TabStop = false;
         
            this.plastiki35.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki35_MouseMove);
            // 
            // plastiki38
            // 
            this.plastiki38.BackColor = System.Drawing.Color.Transparent;
            this.plastiki38.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki38.BackgroundImage")));
            this.plastiki38.Location = new System.Drawing.Point(430, 668);
            this.plastiki38.Name = "plastiki38";
            this.plastiki38.Size = new System.Drawing.Size(45, 80);
            this.plastiki38.TabIndex = 89;
            this.plastiki38.TabStop = false;
        
            this.plastiki38.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki38_MouseMove);
            // 
            // plastiki41
            // 
            this.plastiki41.BackColor = System.Drawing.Color.Transparent;
            this.plastiki41.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki41.BackgroundImage")));
            this.plastiki41.Location = new System.Drawing.Point(430, 668);
            this.plastiki41.Name = "plastiki41";
            this.plastiki41.Size = new System.Drawing.Size(45, 80);
            this.plastiki41.TabIndex = 90;
            this.plastiki41.TabStop = false;
          
            this.plastiki41.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki41_MouseMove);
            // 
            // plastiki44
            // 
            this.plastiki44.BackColor = System.Drawing.Color.Transparent;
            this.plastiki44.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki44.BackgroundImage")));
            this.plastiki44.Location = new System.Drawing.Point(430, 668);
            this.plastiki44.Name = "plastiki44";
            this.plastiki44.Size = new System.Drawing.Size(45, 80);
            this.plastiki44.TabIndex = 91;
            this.plastiki44.TabStop = false;
           
            this.plastiki44.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki44_MouseMove);
            // 
            // plastiki47
            // 
            this.plastiki47.BackColor = System.Drawing.Color.Transparent;
            this.plastiki47.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki47.BackgroundImage")));
            this.plastiki47.Location = new System.Drawing.Point(430, 668);
            this.plastiki47.Name = "plastiki47";
            this.plastiki47.Size = new System.Drawing.Size(45, 80);
            this.plastiki47.TabIndex = 92;
            this.plastiki47.TabStop = false;
           
            this.plastiki47.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki47_MouseMove);
            // 
            // plastiki50
            // 
            this.plastiki50.BackColor = System.Drawing.Color.Transparent;
            this.plastiki50.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki50.BackgroundImage")));
            this.plastiki50.Location = new System.Drawing.Point(430, 668);
            this.plastiki50.Name = "plastiki50";
            this.plastiki50.Size = new System.Drawing.Size(45, 80);
            this.plastiki50.TabIndex = 93;
            this.plastiki50.TabStop = false;
     
            this.plastiki50.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki50_MouseMove);
            // 
            // plastiki53
            // 
            this.plastiki53.BackColor = System.Drawing.Color.Transparent;
            this.plastiki53.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki53.BackgroundImage")));
            this.plastiki53.Location = new System.Drawing.Point(430, 668);
            this.plastiki53.Name = "plastiki53";
            this.plastiki53.Size = new System.Drawing.Size(45, 80);
            this.plastiki53.TabIndex = 94;
            this.plastiki53.TabStop = false;
        
            this.plastiki53.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki53_MouseMove);
            // 
            // plastiki56
            // 
            this.plastiki56.BackColor = System.Drawing.Color.Transparent;
            this.plastiki56.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki56.BackgroundImage")));
            this.plastiki56.Location = new System.Drawing.Point(430, 668);
            this.plastiki56.Name = "plastiki56";
            this.plastiki56.Size = new System.Drawing.Size(45, 80);
            this.plastiki56.TabIndex = 95;
            this.plastiki56.TabStop = false;
      
            this.plastiki56.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki56_MouseMove);
            // 
            // plastiki59
            // 
            this.plastiki59.BackColor = System.Drawing.Color.Transparent;
            this.plastiki59.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki59.BackgroundImage")));
            this.plastiki59.Location = new System.Drawing.Point(430, 668);
            this.plastiki59.Name = "plastiki59";
            this.plastiki59.Size = new System.Drawing.Size(45, 80);
            this.plastiki59.TabIndex = 96;
            this.plastiki59.TabStop = false;
        
            this.plastiki59.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki59_MouseMove);
            // 
            // plastiki62
            // 
            this.plastiki62.BackColor = System.Drawing.Color.Transparent;
            this.plastiki62.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plastiki62.BackgroundImage")));
            this.plastiki62.Location = new System.Drawing.Point(430, 668);
            this.plastiki62.Name = "plastiki62";
            this.plastiki62.Size = new System.Drawing.Size(45, 80);
            this.plastiki62.TabIndex = 97;
            this.plastiki62.TabStop = false;
        
            this.plastiki62.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki62_MouseMove);
            // 
            // szklo1
            // 
            this.szklo1.BackColor = System.Drawing.Color.Transparent;
            this.szklo1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("szklo1.BackgroundImage")));
            this.szklo1.Location = new System.Drawing.Point(904, 702);
            this.szklo1.Name = "szklo1";
            this.szklo1.Size = new System.Drawing.Size(100, 40);
            this.szklo1.TabIndex = 20;
            this.szklo1.TabStop = false;
        
            this.szklo1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo1_MouseMove);
            // 
            // szklo2
            // 
            this.szklo2.BackColor = System.Drawing.Color.Transparent;
            this.szklo2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("szklo2.BackgroundImage")));
            this.szklo2.Location = new System.Drawing.Point(1054, 679);
            this.szklo2.Name = "szklo2";
            this.szklo2.Size = new System.Drawing.Size(43, 60);
            this.szklo2.TabIndex = 21;
            this.szklo2.TabStop = false;
        
            this.szklo2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo2_MouseMove);
            // 
            // szklo3
            // 
            this.szklo3.BackColor = System.Drawing.Color.Transparent;
            this.szklo3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("szklo3.BackgroundImage")));
            this.szklo3.Location = new System.Drawing.Point(1141, 708);
            this.szklo3.Name = "szklo3";
            this.szklo3.Size = new System.Drawing.Size(83, 40);
            this.szklo3.TabIndex = 22;
            this.szklo3.TabStop = false;
        
            this.szklo3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo3_MouseMove);
            // 
            // papier1
            // 
            this.papier1.BackColor = System.Drawing.Color.Transparent;
            this.papier1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("papier1.BackgroundImage")));
            this.papier1.Location = new System.Drawing.Point(12, 679);
            this.papier1.Name = "papier1";
            this.papier1.Size = new System.Drawing.Size(60, 45);
            this.papier1.TabIndex = 23;
            this.papier1.TabStop = false;
          
            this.papier1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier1_MouseMove);
            // 
            // papier2
            // 
            this.papier2.BackColor = System.Drawing.Color.Transparent;
            this.papier2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("papier2.BackgroundImage")));
            this.papier2.Location = new System.Drawing.Point(146, 672);
           
            this.papier2.Size = new System.Drawing.Size(51, 70);
            this.papier2.TabIndex = 24;
            this.papier2.TabStop = false;
           
            this.papier2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier2_MouseMove);
            // 
            // papier3
            // 
            this.papier3.BackColor = System.Drawing.Color.Transparent;
            this.papier3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("papier3.BackgroundImage")));
            this.papier3.Location = new System.Drawing.Point(251, 668);
            this.papier3.Name = "papier3";
            this.papier3.Size = new System.Drawing.Size(50, 73);
            this.papier3.TabIndex = 25;
            this.papier3.TabStop = false;
           
            this.papier3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier3_MouseMove);
            // 
            // organiczne1
            // 
            this.organiczne1.BackColor = System.Drawing.Color.Transparent;
            this.organiczne1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("organiczne1.BackgroundImage")));
            this.organiczne1.Location = new System.Drawing.Point(608, 682);
            this.organiczne1.Name = "organiczne1";
            this.organiczne1.Size = new System.Drawing.Size(44, 60);
            this.organiczne1.TabIndex = 26;
            this.organiczne1.TabStop = false;
          
            this.organiczne1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne1_MouseMove);
            // 
            // organiczne2
            // 
            this.organiczne2.BackColor = System.Drawing.Color.Transparent;
            this.organiczne2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("organiczne2.BackgroundImage")));
            this.organiczne2.Location = new System.Drawing.Point(701, 688);
            this.organiczne2.Name = "organiczne2";
            this.organiczne2.Size = new System.Drawing.Size(57, 60);
            this.organiczne2.TabIndex = 27;
            this.organiczne2.TabStop = false;
            
            this.organiczne2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne2_MouseMove);
            // 
            // organiczne3
            // 
            this.organiczne3.BackColor = System.Drawing.Color.Transparent;
            this.organiczne3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("organiczne3.BackgroundImage")));
            this.organiczne3.Location = new System.Drawing.Point(795, 702);
            this.organiczne3.Name = "organiczne3";
            this.organiczne3.Size = new System.Drawing.Size(67, 47);
            this.organiczne3.TabIndex = 28;
            this.organiczne3.TabStop = false;
           
            this.organiczne3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne3_MouseMove);
            // 
            // GameTimer
            // 
            this.GameTimer.Enabled = true;
            this.GameTimer.Interval = 3000;
            this.GameTimer.Tick += new System.EventHandler(this.TimerEvent);
            // 
            // plastiki6
            // 
            this.plastiki6.BackColor = System.Drawing.Color.Transparent;
            this.plastiki6.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki6.Location = new System.Drawing.Point(511, 679);
            this.plastiki6.Name = "plastiki6";
            this.plastiki6.Size = new System.Drawing.Size(40, 70);
            this.plastiki6.TabIndex = 127;
            this.plastiki6.TabStop = false;
      
            this.plastiki6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki6_MouseMove);
            // 
            // plastiki9
            // 
            this.plastiki9.BackColor = System.Drawing.Color.Transparent;
            this.plastiki9.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki9.Location = new System.Drawing.Point(511, 679);
            this.plastiki9.Name = "plastiki9";
            this.plastiki9.Size = new System.Drawing.Size(40, 70);
            this.plastiki9.TabIndex = 128;
            this.plastiki9.TabStop = false;
         
            this.plastiki9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki9_MouseMove);
            // 
            // plastiki12
            // 
            this.plastiki12.BackColor = System.Drawing.Color.Transparent;
            this.plastiki12.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki12.Location = new System.Drawing.Point(511, 679);
            this.plastiki12.Name = "plastiki12";
            this.plastiki12.Size = new System.Drawing.Size(40, 70);
            this.plastiki12.TabIndex = 129;
            this.plastiki12.TabStop = false;
         
            this.plastiki12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki12_MouseMove);
            // 
            // plastiki15
            // 
            this.plastiki15.BackColor = System.Drawing.Color.Transparent;
            this.plastiki15.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki15.Location = new System.Drawing.Point(511, 679);
            this.plastiki15.Name = "plastiki15";
            this.plastiki15.Size = new System.Drawing.Size(40, 70);
            this.plastiki15.TabIndex = 130;
            this.plastiki15.TabStop = false;
        
            this.plastiki15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki15_MouseMove);
            // 
            // plastiki18
            // 
            this.plastiki18.BackColor = System.Drawing.Color.Transparent;
            this.plastiki18.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki18.Location = new System.Drawing.Point(511, 679);
            this.plastiki18.Name = "plastiki18";
            this.plastiki18.Size = new System.Drawing.Size(40, 70);
            this.plastiki18.TabIndex = 131;
            this.plastiki18.TabStop = false;
           
            this.plastiki18.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki18_MouseMove);
            // 
            // plastiki21
            // 
            this.plastiki21.BackColor = System.Drawing.Color.Transparent;
            this.plastiki21.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki21.Location = new System.Drawing.Point(511, 679);
            this.plastiki21.Name = "plastiki21";
            this.plastiki21.Size = new System.Drawing.Size(40, 70);
            this.plastiki21.TabIndex = 132;
            this.plastiki21.TabStop = false;
            
            this.plastiki21.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki21_MouseMove);
            // 
            // plastiki24
            // 
            this.plastiki24.BackColor = System.Drawing.Color.Transparent;
            this.plastiki24.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki24.Location = new System.Drawing.Point(511, 679);
            this.plastiki24.Name = "plastiki24";
            this.plastiki24.Size = new System.Drawing.Size(40, 70);
            this.plastiki24.TabIndex = 133;
            this.plastiki24.TabStop = false;
         
            this.plastiki24.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki24_MouseMove);
            // 
            // plastiki27
            // 
            this.plastiki27.BackColor = System.Drawing.Color.Transparent;
            this.plastiki27.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki27.Location = new System.Drawing.Point(511, 679);
            this.plastiki27.Name = "plastiki27";
            this.plastiki27.Size = new System.Drawing.Size(40, 70);
            this.plastiki27.TabIndex = 134;
            this.plastiki27.TabStop = false;
        
            this.plastiki27.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki27_MouseMove);
            // 
            // plastiki30
            // 
            this.plastiki30.BackColor = System.Drawing.Color.Transparent;
            this.plastiki30.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki30.Location = new System.Drawing.Point(511, 679);
            this.plastiki30.Name = "plastiki30";
            this.plastiki30.Size = new System.Drawing.Size(40, 70);
            this.plastiki30.TabIndex = 135;
            this.plastiki30.TabStop = false;
         
            this.plastiki30.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki30_MouseMove);
            // 
            // plastiki33
            // 
            this.plastiki33.BackColor = System.Drawing.Color.Transparent;
            this.plastiki33.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki33.Location = new System.Drawing.Point(511, 679);
            this.plastiki33.Name = "plastiki33";
            this.plastiki33.Size = new System.Drawing.Size(40, 70);
            this.plastiki33.TabIndex = 136;
            this.plastiki33.TabStop = false;
         
            this.plastiki33.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki33_MouseMove);
            // 
            // plastiki36
            // 
            this.plastiki36.BackColor = System.Drawing.Color.Transparent;
            this.plastiki36.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki36.Location = new System.Drawing.Point(511, 679);
            this.plastiki36.Name = "plastiki36";
            this.plastiki36.Size = new System.Drawing.Size(40, 70);
            this.plastiki36.TabIndex = 137;
            this.plastiki36.TabStop = false;
    
            this.plastiki36.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki36_MouseMove);
            // 
            // plastiki39
            // 
            this.plastiki39.BackColor = System.Drawing.Color.Transparent;
            this.plastiki39.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki39.Location = new System.Drawing.Point(511, 679);
            this.plastiki39.Name = "plastiki39";
            this.plastiki39.Size = new System.Drawing.Size(40, 70);
            this.plastiki39.TabIndex = 138;
            this.plastiki39.TabStop = false;
        
            this.plastiki39.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki39_MouseMove);
            // 
            // plastiki42
            // 
            this.plastiki42.BackColor = System.Drawing.Color.Transparent;
            this.plastiki42.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki42.Location = new System.Drawing.Point(511, 679);
            this.plastiki42.Name = "plastiki42";
            this.plastiki42.Size = new System.Drawing.Size(40, 70);
            this.plastiki42.TabIndex = 139;
            this.plastiki42.TabStop = false;
          
            this.plastiki42.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki42_MouseMove);
            // 
            // plastiki45
            // 
            this.plastiki45.BackColor = System.Drawing.Color.Transparent;
            this.plastiki45.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki45.Location = new System.Drawing.Point(511, 679);
            this.plastiki45.Name = "plastiki45";
            this.plastiki45.Size = new System.Drawing.Size(40, 70);
            this.plastiki45.TabIndex = 140;
            this.plastiki45.TabStop = false;
          
            this.plastiki45.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki45_MouseMove);
            // 
            // plastiki48
            // 
            this.plastiki48.BackColor = System.Drawing.Color.Transparent;
            this.plastiki48.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki48.Location = new System.Drawing.Point(511, 679);
            this.plastiki48.Name = "plastiki48";
            this.plastiki48.Size = new System.Drawing.Size(40, 70);
            this.plastiki48.TabIndex = 141;
            this.plastiki48.TabStop = false;
         
            this.plastiki48.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki48_MouseMove);
            // 
            // plastiki51
            // 
            this.plastiki51.BackColor = System.Drawing.Color.Transparent;
            this.plastiki51.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki51.Location = new System.Drawing.Point(511, 679);
            this.plastiki51.Name = "plastiki51";
            this.plastiki51.Size = new System.Drawing.Size(40, 70);
            this.plastiki51.TabIndex = 142;
            this.plastiki51.TabStop = false;
     
            this.plastiki51.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki51_MouseMove);
            // 
            // plastiki54
            // 
            this.plastiki54.BackColor = System.Drawing.Color.Transparent;
            this.plastiki54.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki54.Location = new System.Drawing.Point(511, 679);
            this.plastiki54.Name = "plastiki54";
            this.plastiki54.Size = new System.Drawing.Size(40, 70);
            this.plastiki54.TabIndex = 143;
            this.plastiki54.TabStop = false;
     
            this.plastiki54.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki54_MouseMove);
            // 
            // plastiki57
            // 
            this.plastiki57.BackColor = System.Drawing.Color.Transparent;
            this.plastiki57.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki57.Location = new System.Drawing.Point(511, 679);
            this.plastiki57.Name = "plastiki57";
            this.plastiki57.Size = new System.Drawing.Size(40, 70);
            this.plastiki57.TabIndex = 144;
            this.plastiki57.TabStop = false;
          
            this.plastiki57.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki57_MouseMove);
            // 
            // plastiki60
            // 
            this.plastiki60.BackColor = System.Drawing.Color.Transparent;
            this.plastiki60.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki60.Location = new System.Drawing.Point(511, 679);
            this.plastiki60.Name = "plastiki60";
            this.plastiki60.Size = new System.Drawing.Size(40, 70);
            this.plastiki60.TabIndex = 145;
            this.plastiki60.TabStop = false;
        
            this.plastiki60.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki60_MouseMove);
            // 
            // plastiki63
            // 
            this.plastiki63.BackColor = System.Drawing.Color.Transparent;
            this.plastiki63.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.puszka__1__removebg_preview;
            this.plastiki63.Location = new System.Drawing.Point(511, 679);
            this.plastiki63.Name = "plastiki63";
            this.plastiki63.Size = new System.Drawing.Size(40, 70);
            this.plastiki63.TabIndex = 146;
            this.plastiki63.TabStop = false;
       
            this.plastiki63.MouseMove += new System.Windows.Forms.MouseEventHandler(this.plastiki63_MouseMove);
            // 
            // organiczne4
            // 
            this.organiczne4.BackColor = System.Drawing.Color.Transparent;
            this.organiczne4.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne4.Location = new System.Drawing.Point(608, 682);
            this.organiczne4.Name = "organiczne4";
            this.organiczne4.Size = new System.Drawing.Size(44, 60);
            this.organiczne4.TabIndex = 147;
            this.organiczne4.TabStop = false;
          
            this.organiczne4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne4_MouseMove);
            // 
            // organiczne7
            // 
            this.organiczne7.BackColor = System.Drawing.Color.Transparent;
            this.organiczne7.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne7.Location = new System.Drawing.Point(608, 682);
            this.organiczne7.Name = "organiczne7";
            this.organiczne7.Size = new System.Drawing.Size(44, 60);
            this.organiczne7.TabIndex = 148;
            this.organiczne7.TabStop = false;
         
            this.organiczne7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne7_MouseMove);
            // 
            // organiczne10
            // 
            this.organiczne10.BackColor = System.Drawing.Color.Transparent;
            this.organiczne10.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne10.Location = new System.Drawing.Point(608, 682);
            this.organiczne10.Name = "organiczne10";
            this.organiczne10.Size = new System.Drawing.Size(44, 60);
            this.organiczne10.TabIndex = 149;
            this.organiczne10.TabStop = false;
       
            this.organiczne10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne10_MouseMove);
            // 
            // organiczne13
            // 
            this.organiczne13.BackColor = System.Drawing.Color.Transparent;
            this.organiczne13.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne13.Location = new System.Drawing.Point(608, 682);
            this.organiczne13.Name = "organiczne13";
            this.organiczne13.Size = new System.Drawing.Size(44, 60);
            this.organiczne13.TabIndex = 150;
            this.organiczne13.TabStop = false;
      
            this.organiczne13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne13_MouseMove);
            // 
            // organiczne16
            // 
            this.organiczne16.BackColor = System.Drawing.Color.Transparent;
            this.organiczne16.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne16.Location = new System.Drawing.Point(608, 682);
            this.organiczne16.Name = "organiczne16";
            this.organiczne16.Size = new System.Drawing.Size(44, 60);
            this.organiczne16.TabIndex = 151;
            this.organiczne16.TabStop = false;
         
            this.organiczne16.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne16_MouseMove);
            // 
            // organiczne19
            // 
            this.organiczne19.BackColor = System.Drawing.Color.Transparent;
            this.organiczne19.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne19.Location = new System.Drawing.Point(608, 682);
            this.organiczne19.Name = "organiczne19";
            this.organiczne19.Size = new System.Drawing.Size(44, 60);
            this.organiczne19.TabIndex = 152;
            this.organiczne19.TabStop = false;
       
            this.organiczne19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne19_MouseMove);
            // 
            // organiczne22
            // 
            this.organiczne22.BackColor = System.Drawing.Color.Transparent;
            this.organiczne22.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne22.Location = new System.Drawing.Point(608, 682);
            this.organiczne22.Name = "organiczne22";
            this.organiczne22.Size = new System.Drawing.Size(44, 60);
            this.organiczne22.TabIndex = 153;
            this.organiczne22.TabStop = false;
      
            this.organiczne22.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne22_MouseMove);
            // 
            // organiczne25
            // 
            this.organiczne25.BackColor = System.Drawing.Color.Transparent;
            this.organiczne25.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne25.Location = new System.Drawing.Point(608, 682);
            this.organiczne25.Name = "organiczne25";
            this.organiczne25.Size = new System.Drawing.Size(44, 60);
            this.organiczne25.TabIndex = 154;
            this.organiczne25.TabStop = false;
       
            this.organiczne25.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne25_MouseMove);
            // 
            // organiczne28
            // 
            this.organiczne28.BackColor = System.Drawing.Color.Transparent;
            this.organiczne28.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne28.Location = new System.Drawing.Point(608, 682);
            this.organiczne28.Name = "organiczne28";
            this.organiczne28.Size = new System.Drawing.Size(44, 60);
            this.organiczne28.TabIndex = 155;
            this.organiczne28.TabStop = false;
      
            this.organiczne28.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne28_MouseMove);
            // 
            // organiczne31
            // 
            this.organiczne31.BackColor = System.Drawing.Color.Transparent;
            this.organiczne31.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne31.Location = new System.Drawing.Point(608, 682);
            this.organiczne31.Name = "organiczne31";
            this.organiczne31.Size = new System.Drawing.Size(44, 60);
            this.organiczne31.TabIndex = 156;
            this.organiczne31.TabStop = false;
        
            this.organiczne31.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne31_MouseMove);
            // 
            // organiczne34
            // 
            this.organiczne34.BackColor = System.Drawing.Color.Transparent;
            this.organiczne34.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne34.Location = new System.Drawing.Point(608, 682);
            this.organiczne34.Name = "organiczne34";
            this.organiczne34.Size = new System.Drawing.Size(44, 60);
            this.organiczne34.TabIndex = 157;
            this.organiczne34.TabStop = false;
      
            this.organiczne34.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne34_MouseMove);
            // 
            // organiczne37
            // 
            this.organiczne37.BackColor = System.Drawing.Color.Transparent;
            this.organiczne37.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne37.Location = new System.Drawing.Point(608, 682);
            this.organiczne37.Name = "organiczne37";
            this.organiczne37.Size = new System.Drawing.Size(44, 60);
            this.organiczne37.TabIndex = 158;
            this.organiczne37.TabStop = false;
         
            this.organiczne37.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne37_MouseMove);
            // 
            // organiczne40
            // 
            this.organiczne40.BackColor = System.Drawing.Color.Transparent;
            this.organiczne40.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne40.Location = new System.Drawing.Point(608, 682);
            this.organiczne40.Name = "organiczne40";
            this.organiczne40.Size = new System.Drawing.Size(44, 60);
            this.organiczne40.TabIndex = 159;
            this.organiczne40.TabStop = false;
     
            this.organiczne40.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne40_MouseMove);
            // 
            // organiczne43
            // 
            this.organiczne43.BackColor = System.Drawing.Color.Transparent;
            this.organiczne43.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne43.Location = new System.Drawing.Point(608, 682);
            this.organiczne43.Name = "organiczne43";
            this.organiczne43.Size = new System.Drawing.Size(44, 60);
            this.organiczne43.TabIndex = 160;
            this.organiczne43.TabStop = false;
  
            this.organiczne43.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne43_MouseMove);
            // 
            // organiczne46
            // 
            this.organiczne46.BackColor = System.Drawing.Color.Transparent;
            this.organiczne46.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne46.Location = new System.Drawing.Point(608, 682);
            this.organiczne46.Name = "organiczne46";
            this.organiczne46.Size = new System.Drawing.Size(44, 60);
            this.organiczne46.TabIndex = 161;
            this.organiczne46.TabStop = false;
         
            this.organiczne46.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne46_MouseMove);
            // 
            // organiczne49
            // 
            this.organiczne49.BackColor = System.Drawing.Color.Transparent;
            this.organiczne49.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne49.Location = new System.Drawing.Point(608, 682);
            this.organiczne49.Name = "organiczne49";
            this.organiczne49.Size = new System.Drawing.Size(44, 60);
            this.organiczne49.TabIndex = 162;
            this.organiczne49.TabStop = false;
     
            this.organiczne49.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne49_MouseMove);
            // 
            // organiczne52
            // 
            this.organiczne52.BackColor = System.Drawing.Color.Transparent;
            this.organiczne52.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne52.Location = new System.Drawing.Point(608, 682);
            this.organiczne52.Name = "organiczne52";
            this.organiczne52.Size = new System.Drawing.Size(44, 60);
            this.organiczne52.TabIndex = 163;
            this.organiczne52.TabStop = false;
        
            this.organiczne52.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne52_MouseMove);
            // 
            // organiczne55
            // 
            this.organiczne55.BackColor = System.Drawing.Color.Transparent;
            this.organiczne55.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne55.Location = new System.Drawing.Point(608, 682);
            this.organiczne55.Name = "organiczne55";
            this.organiczne55.Size = new System.Drawing.Size(44, 60);
            this.organiczne55.TabIndex = 164;
            this.organiczne55.TabStop = false;
      
            this.organiczne55.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne55_MouseMove);
            // 
            // organiczne58
            // 
            this.organiczne58.BackColor = System.Drawing.Color.Transparent;
            this.organiczne58.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne58.Location = new System.Drawing.Point(608, 682);
            this.organiczne58.Name = "organiczne58";
            this.organiczne58.Size = new System.Drawing.Size(44, 60);
            this.organiczne58.TabIndex = 165;
            this.organiczne58.TabStop = false;
         
            this.organiczne58.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne58_MouseMove);
            // 
            // organiczne61
            // 
            this.organiczne61.BackColor = System.Drawing.Color.Transparent;
            this.organiczne61.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.ogryzek__1__removebg_preview;
            this.organiczne61.Location = new System.Drawing.Point(608, 682);
            this.organiczne61.Name = "organiczne61";
            this.organiczne61.Size = new System.Drawing.Size(44, 60);
            this.organiczne61.TabIndex = 166;
            this.organiczne61.TabStop = false;
       
            this.organiczne61.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne61_MouseMove);
            // 
            // organiczne5
            // 
            this.organiczne5.BackColor = System.Drawing.Color.Transparent;
            this.organiczne5.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne5.Location = new System.Drawing.Point(701, 688);
            this.organiczne5.Name = "organiczne5";
            this.organiczne5.Size = new System.Drawing.Size(57, 60);
            this.organiczne5.TabIndex = 167;
            this.organiczne5.TabStop = false;
       
            this.organiczne5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne5_MouseMove);
            // 
            // organiczne8
            // 
            this.organiczne8.BackColor = System.Drawing.Color.Transparent;
            this.organiczne8.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne8.Location = new System.Drawing.Point(701, 688);
            this.organiczne8.Name = "organiczne8";
            this.organiczne8.Size = new System.Drawing.Size(57, 60);
            this.organiczne8.TabIndex = 168;
            this.organiczne8.TabStop = false;
        
            this.organiczne8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne8_MouseMove);
            // 
            // organiczne11
            // 
            this.organiczne11.BackColor = System.Drawing.Color.Transparent;
            this.organiczne11.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne11.Location = new System.Drawing.Point(701, 688);
            this.organiczne11.Name = "organiczne11";
            this.organiczne11.Size = new System.Drawing.Size(57, 60);
            this.organiczne11.TabIndex = 169;
            this.organiczne11.TabStop = false;
    
            this.organiczne11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne11_MouseMove);
            // 
            // organiczne14
            // 
            this.organiczne14.BackColor = System.Drawing.Color.Transparent;
            this.organiczne14.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne14.Location = new System.Drawing.Point(701, 688);
            this.organiczne14.Name = "organiczne14";
            this.organiczne14.Size = new System.Drawing.Size(57, 60);
            this.organiczne14.TabIndex = 170;
            this.organiczne14.TabStop = false;
    
            this.organiczne14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne14_MouseMove);
            // 
            // organiczne17
            // 
            this.organiczne17.BackColor = System.Drawing.Color.Transparent;
            this.organiczne17.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne17.Location = new System.Drawing.Point(701, 688);
            this.organiczne17.Name = "organiczne17";
            this.organiczne17.Size = new System.Drawing.Size(57, 60);
            this.organiczne17.TabIndex = 171;
            this.organiczne17.TabStop = false;
       
            this.organiczne17.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne17_MouseMove);
            // 
            // organiczne20
            // 
            this.organiczne20.BackColor = System.Drawing.Color.Transparent;
            this.organiczne20.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne20.Location = new System.Drawing.Point(701, 688);
            this.organiczne20.Name = "organiczne20";
            this.organiczne20.Size = new System.Drawing.Size(57, 60);
            this.organiczne20.TabIndex = 172;
            this.organiczne20.TabStop = false;
      
            this.organiczne20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne20_MouseMove);
            // 
            // organiczne23
            // 
            this.organiczne23.BackColor = System.Drawing.Color.Transparent;
            this.organiczne23.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne23.Location = new System.Drawing.Point(701, 688);
            this.organiczne23.Name = "organiczne23";
            this.organiczne23.Size = new System.Drawing.Size(57, 60);
            this.organiczne23.TabIndex = 173;
            this.organiczne23.TabStop = false;
       
            this.organiczne23.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne23_MouseMove);
            // 
            // organiczne26
            // 
            this.organiczne26.BackColor = System.Drawing.Color.Transparent;
            this.organiczne26.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne26.Location = new System.Drawing.Point(701, 688);
            this.organiczne26.Name = "organiczne26";
            this.organiczne26.Size = new System.Drawing.Size(57, 60);
            this.organiczne26.TabIndex = 174;
            this.organiczne26.TabStop = false;
 
            this.organiczne26.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne26_MouseMove);
            // 
            // organiczne29
            // 
            this.organiczne29.BackColor = System.Drawing.Color.Transparent;
            this.organiczne29.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne29.Location = new System.Drawing.Point(701, 688);
            this.organiczne29.Name = "organiczne29";
            this.organiczne29.Size = new System.Drawing.Size(57, 60);
            this.organiczne29.TabIndex = 175;
            this.organiczne29.TabStop = false;
        
            this.organiczne29.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne29_MouseMove);
            // 
            // organiczne32
            // 
            this.organiczne32.BackColor = System.Drawing.Color.Transparent;
            this.organiczne32.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne32.Location = new System.Drawing.Point(701, 688);
            this.organiczne32.Name = "organiczne32";
            this.organiczne32.Size = new System.Drawing.Size(57, 60);
            this.organiczne32.TabIndex = 176;
            this.organiczne32.TabStop = false;
         
            this.organiczne32.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne32_MouseMove);
            // 
            // organiczne35
            // 
            this.organiczne35.BackColor = System.Drawing.Color.Transparent;
            this.organiczne35.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne35.Location = new System.Drawing.Point(701, 688);
            this.organiczne35.Name = "organiczne35";
            this.organiczne35.Size = new System.Drawing.Size(57, 60);
            this.organiczne35.TabIndex = 177;
            this.organiczne35.TabStop = false;
  
            this.organiczne35.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne35_MouseMove);
            // 
            // organiczne38
            // 
            this.organiczne38.BackColor = System.Drawing.Color.Transparent;
            this.organiczne38.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne38.Location = new System.Drawing.Point(701, 688);
            this.organiczne38.Name = "organiczne38";
            this.organiczne38.Size = new System.Drawing.Size(57, 60);
            this.organiczne38.TabIndex = 178;
            this.organiczne38.TabStop = false;
          
            this.organiczne38.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne38_MouseMove);
            // 
            // organiczne41
            // 
            this.organiczne41.BackColor = System.Drawing.Color.Transparent;
            this.organiczne41.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne41.Location = new System.Drawing.Point(701, 688);
            this.organiczne41.Name = "organiczne41";
            this.organiczne41.Size = new System.Drawing.Size(57, 60);
            this.organiczne41.TabIndex = 179;
            this.organiczne41.TabStop = false;
         
            this.organiczne41.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne41_MouseMove);
            // 
            // organiczne44
            // 
            this.organiczne44.BackColor = System.Drawing.Color.Transparent;
            this.organiczne44.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne44.Location = new System.Drawing.Point(701, 688);
            this.organiczne44.Name = "organiczne44";
            this.organiczne44.Size = new System.Drawing.Size(57, 60);
            this.organiczne44.TabIndex = 180;
            this.organiczne44.TabStop = false;
            
            this.organiczne44.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne44_MouseMove);
            // 
            // organiczne47
            // 
            this.organiczne47.BackColor = System.Drawing.Color.Transparent;
            this.organiczne47.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne47.Location = new System.Drawing.Point(701, 688);
            this.organiczne47.Name = "organiczne47";
            this.organiczne47.Size = new System.Drawing.Size(57, 60);
            this.organiczne47.TabIndex = 181;
            this.organiczne47.TabStop = false;
           
            this.organiczne47.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne47_MouseMove);
            // 
            // organiczne50
            // 
            this.organiczne50.BackColor = System.Drawing.Color.Transparent;
            this.organiczne50.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne50.Location = new System.Drawing.Point(701, 688);
            this.organiczne50.Name = "organiczne50";
            this.organiczne50.Size = new System.Drawing.Size(57, 60);
            this.organiczne50.TabIndex = 182;
            this.organiczne50.TabStop = false;
          
            this.organiczne50.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne50_MouseMove);
            // 
            // organiczne53
            // 
            this.organiczne53.BackColor = System.Drawing.Color.Transparent;
            this.organiczne53.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne53.Location = new System.Drawing.Point(701, 688);
            this.organiczne53.Name = "organiczne53";
            this.organiczne53.Size = new System.Drawing.Size(57, 60);
            this.organiczne53.TabIndex = 183;
            this.organiczne53.TabStop = false;
           
            this.organiczne53.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne53_MouseMove);
            // 
            // organiczne56
            // 
            this.organiczne56.BackColor = System.Drawing.Color.Transparent;
            this.organiczne56.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne56.Location = new System.Drawing.Point(701, 688);
            this.organiczne56.Name = "organiczne56";
            this.organiczne56.Size = new System.Drawing.Size(57, 60);
            this.organiczne56.TabIndex = 184;
            this.organiczne56.TabStop = false;
           
            this.organiczne56.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne56_MouseMove);
            // 
            // organiczne59
            // 
            this.organiczne59.BackColor = System.Drawing.Color.Transparent;
            this.organiczne59.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne59.Location = new System.Drawing.Point(701, 688);
            this.organiczne59.Name = "organiczne59";
            this.organiczne59.Size = new System.Drawing.Size(57, 60);
            this.organiczne59.TabIndex = 185;
            this.organiczne59.TabStop = false;
            
            this.organiczne59.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne59_MouseMove);
            // 
            // organiczne62
            // 
            this.organiczne62.BackColor = System.Drawing.Color.Transparent;
            this.organiczne62.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.tea__1__removebg_preview;
            this.organiczne62.Location = new System.Drawing.Point(701, 688);
            this.organiczne62.Name = "organiczne62";
            this.organiczne62.Size = new System.Drawing.Size(57, 60);
            this.organiczne62.TabIndex = 186;
            this.organiczne62.TabStop = false;
        
            this.organiczne62.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne62_MouseMove);
            // 
            // organiczne6
            // 
            this.organiczne6.BackColor = System.Drawing.Color.Transparent;
            this.organiczne6.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne6.Location = new System.Drawing.Point(795, 702);
            this.organiczne6.Name = "organiczne6";
            this.organiczne6.Size = new System.Drawing.Size(67, 47);
            this.organiczne6.TabIndex = 187;
            this.organiczne6.TabStop = false;
       
            this.organiczne6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne6_MouseMove);
            // 
            // organiczne9
            // 
            this.organiczne9.BackColor = System.Drawing.Color.Transparent;
            this.organiczne9.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne9.Location = new System.Drawing.Point(795, 702);
            this.organiczne9.Name = "organiczne9";
            this.organiczne9.Size = new System.Drawing.Size(67, 47);
            this.organiczne9.TabIndex = 188;
            this.organiczne9.TabStop = false;
     
            this.organiczne9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne9_MouseMove);
            // 
            // organiczne12
            // 
            this.organiczne12.BackColor = System.Drawing.Color.Transparent;
            this.organiczne12.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne12.Location = new System.Drawing.Point(795, 702);
            this.organiczne12.Name = "organiczne12";
            this.organiczne12.Size = new System.Drawing.Size(67, 47);
            this.organiczne12.TabIndex = 189;
            this.organiczne12.TabStop = false;
   
            this.organiczne12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne12_MouseMove);
            // 
            // organiczne15
            // 
            this.organiczne15.BackColor = System.Drawing.Color.Transparent;
            this.organiczne15.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne15.Location = new System.Drawing.Point(795, 702);
            this.organiczne15.Name = "organiczne15";
            this.organiczne15.Size = new System.Drawing.Size(67, 47);
            this.organiczne15.TabIndex = 190;
            this.organiczne15.TabStop = false;
         
            this.organiczne15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne15_MouseMove);
            // 
            // organiczne18
            // 
            this.organiczne18.BackColor = System.Drawing.Color.Transparent;
            this.organiczne18.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne18.Location = new System.Drawing.Point(795, 702);
            this.organiczne18.Name = "organiczne18";
            this.organiczne18.Size = new System.Drawing.Size(67, 47);
            this.organiczne18.TabIndex = 191;
            this.organiczne18.TabStop = false;
         
            this.organiczne18.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne18_MouseMove);
            // 
            // organiczne21
            // 
            this.organiczne21.BackColor = System.Drawing.Color.Transparent;
            this.organiczne21.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne21.Location = new System.Drawing.Point(795, 702);
            this.organiczne21.Name = "organiczne21";
            this.organiczne21.Size = new System.Drawing.Size(67, 47);
            this.organiczne21.TabIndex = 192;
            this.organiczne21.TabStop = false;
            
            this.organiczne21.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne21_MouseMove);
            // 
            // organiczne24
            // 
            this.organiczne24.BackColor = System.Drawing.Color.Transparent;
            this.organiczne24.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne24.Location = new System.Drawing.Point(795, 702);
            this.organiczne24.Name = "organiczne24";
            this.organiczne24.Size = new System.Drawing.Size(67, 47);
            this.organiczne24.TabIndex = 193;
            this.organiczne24.TabStop = false;
         
            this.organiczne24.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne24_MouseMove);
            // 
            // organiczne27
            // 
            this.organiczne27.BackColor = System.Drawing.Color.Transparent;
            this.organiczne27.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne27.Location = new System.Drawing.Point(795, 702);
            this.organiczne27.Name = "organiczne27";
            this.organiczne27.Size = new System.Drawing.Size(67, 47);
            this.organiczne27.TabIndex = 194;
            this.organiczne27.TabStop = false;
        
            this.organiczne27.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne27_MouseMove);
            // 
            // organiczne30
            // 
            this.organiczne30.BackColor = System.Drawing.Color.Transparent;
            this.organiczne30.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne30.Location = new System.Drawing.Point(795, 702);
            this.organiczne30.Name = "organiczne30";
            this.organiczne30.Size = new System.Drawing.Size(67, 47);
            this.organiczne30.TabIndex = 195;
            this.organiczne30.TabStop = false;
          
            this.organiczne30.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne30_MouseMove);
            // 
            // organiczne33
            // 
            this.organiczne33.BackColor = System.Drawing.Color.Transparent;
            this.organiczne33.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne33.Location = new System.Drawing.Point(795, 702);
            this.organiczne33.Name = "organiczne33";
            this.organiczne33.Size = new System.Drawing.Size(67, 47);
            this.organiczne33.TabIndex = 196;
            this.organiczne33.TabStop = false;
        
            this.organiczne33.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne33_MouseMove);
            // 
            // organiczne36
            // 
            this.organiczne36.BackColor = System.Drawing.Color.Transparent;
            this.organiczne36.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne36.Location = new System.Drawing.Point(795, 702);
            this.organiczne36.Name = "organiczne36";
            this.organiczne36.Size = new System.Drawing.Size(67, 47);
            this.organiczne36.TabIndex = 197;
            this.organiczne36.TabStop = false;
       
            this.organiczne36.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne36_MouseMove);
            // 
            // organiczne39
            // 
            this.organiczne39.BackColor = System.Drawing.Color.Transparent;
            this.organiczne39.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne39.Location = new System.Drawing.Point(795, 702);
            this.organiczne39.Name = "organiczne39";
            this.organiczne39.Size = new System.Drawing.Size(67, 47);
            this.organiczne39.TabIndex = 198;
            this.organiczne39.TabStop = false;
            
            this.organiczne39.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne39_MouseMove);
            // 
            // organiczne42
            // 
            this.organiczne42.BackColor = System.Drawing.Color.Transparent;
            this.organiczne42.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne42.Location = new System.Drawing.Point(795, 702);
            this.organiczne42.Name = "organiczne42";
            this.organiczne42.Size = new System.Drawing.Size(67, 47);
            this.organiczne42.TabIndex = 199;
            this.organiczne42.TabStop = false;
           
            this.organiczne42.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne42_MouseMove);
            // 
            // organiczne45
            // 
            this.organiczne45.BackColor = System.Drawing.Color.Transparent;
            this.organiczne45.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne45.Location = new System.Drawing.Point(795, 702);
            this.organiczne45.Name = "organiczne45";
            this.organiczne45.Size = new System.Drawing.Size(67, 47);
            this.organiczne45.TabIndex = 200;
            this.organiczne45.TabStop = false;
          
            this.organiczne45.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne45_MouseMove);
            // 
            // organiczne48
            // 
            this.organiczne48.BackColor = System.Drawing.Color.Transparent;
            this.organiczne48.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne48.Location = new System.Drawing.Point(795, 702);
            this.organiczne48.Name = "organiczne48";
            this.organiczne48.Size = new System.Drawing.Size(67, 47);
            this.organiczne48.TabIndex = 201;
            this.organiczne48.TabStop = false;
          
            this.organiczne48.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne48_MouseMove);
            // 
            // organiczne51
            // 
            this.organiczne51.BackColor = System.Drawing.Color.Transparent;
            this.organiczne51.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne51.Location = new System.Drawing.Point(795, 702);
            this.organiczne51.Name = "organiczne51";
            this.organiczne51.Size = new System.Drawing.Size(67, 47);
            this.organiczne51.TabIndex = 202;
            this.organiczne51.TabStop = false;
           
            this.organiczne51.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne51_MouseMove);
            // 
            // organiczne54
            // 
            this.organiczne54.BackColor = System.Drawing.Color.Transparent;
            this.organiczne54.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne54.Location = new System.Drawing.Point(795, 702);
            this.organiczne54.Name = "organiczne54";
            this.organiczne54.Size = new System.Drawing.Size(67, 47);
            this.organiczne54.TabIndex = 203;
            this.organiczne54.TabStop = false;
           
            this.organiczne54.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne54_MouseMove);
            // 
            // organiczne57
            // 
            this.organiczne57.BackColor = System.Drawing.Color.Transparent;
            this.organiczne57.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne57.Location = new System.Drawing.Point(795, 702);
            this.organiczne57.Name = "organiczne57";
            this.organiczne57.Size = new System.Drawing.Size(67, 47);
            this.organiczne57.TabIndex = 204;
            this.organiczne57.TabStop = false;
          
            this.organiczne57.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne57_MouseMove);
            // 
            // organiczne60
            // 
            this.organiczne60.BackColor = System.Drawing.Color.Transparent;
            this.organiczne60.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne60.Location = new System.Drawing.Point(795, 702);
            this.organiczne60.Name = "organiczne60";
            this.organiczne60.Size = new System.Drawing.Size(67, 47);
            this.organiczne60.TabIndex = 205;
            this.organiczne60.TabStop = false;
         
            this.organiczne60.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne60_MouseMove);
            // 
            // organiczne63
            // 
            this.organiczne63.BackColor = System.Drawing.Color.Transparent;
            this.organiczne63.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.jajo__1__removebg_preview;
            this.organiczne63.Location = new System.Drawing.Point(795, 702);
            this.organiczne63.Name = "organiczne63";
            this.organiczne63.Size = new System.Drawing.Size(67, 47);
            this.organiczne63.TabIndex = 206;
            this.organiczne63.TabStop = false;
          
            this.organiczne63.MouseMove += new System.Windows.Forms.MouseEventHandler(this.organiczne63_MouseMove);
            // 
            // szklo4
            // 
            this.szklo4.BackColor = System.Drawing.Color.Transparent;
            this.szklo4.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo4.Location = new System.Drawing.Point(904, 702);
            this.szklo4.Name = "szklo4";
            this.szklo4.Size = new System.Drawing.Size(100, 40);
            this.szklo4.TabIndex = 207;
            this.szklo4.TabStop = false;
       
            this.szklo4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo4_MouseMove);
            // 
            // szklo7
            // 
            this.szklo7.BackColor = System.Drawing.Color.Transparent;
            this.szklo7.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo7.Location = new System.Drawing.Point(904, 702);
            this.szklo7.Name = "szklo7";
            this.szklo7.Size = new System.Drawing.Size(100, 40);
            this.szklo7.TabIndex = 208;
            this.szklo7.TabStop = false;
       
            this.szklo7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo7_MouseMove);
            // 
            // szklo10
            // 
            this.szklo10.BackColor = System.Drawing.Color.Transparent;
            this.szklo10.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo10.Location = new System.Drawing.Point(904, 702);
            this.szklo10.Name = "szklo10";
            this.szklo10.Size = new System.Drawing.Size(100, 40);
            this.szklo10.TabIndex = 209;
            this.szklo10.TabStop = false;
        
            this.szklo10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo10_MouseMove);
            // 
            // szklo13
            // 
            this.szklo13.BackColor = System.Drawing.Color.Transparent;
            this.szklo13.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo13.Location = new System.Drawing.Point(904, 702);
            this.szklo13.Name = "szklo13";
            this.szklo13.Size = new System.Drawing.Size(100, 40);
            this.szklo13.TabIndex = 210;
            this.szklo13.TabStop = false;
        
            this.szklo13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo13_MouseMove);
            // 
            // szklo16
            // 
            this.szklo16.BackColor = System.Drawing.Color.Transparent;
            this.szklo16.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo16.Location = new System.Drawing.Point(904, 702);
            this.szklo16.Name = "szklo16";
            this.szklo16.Size = new System.Drawing.Size(100, 40);
            this.szklo16.TabIndex = 211;
            this.szklo16.TabStop = false;
         
            this.szklo16.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo16_MouseMove);
            // 
            // szklo19
            // 
            this.szklo19.BackColor = System.Drawing.Color.Transparent;
            this.szklo19.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo19.Location = new System.Drawing.Point(904, 702);
            this.szklo19.Name = "szklo19";
            this.szklo19.Size = new System.Drawing.Size(100, 40);
            this.szklo19.TabIndex = 212;
            this.szklo19.TabStop = false;
        
            this.szklo19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo19_MouseMove);
            // 
            // szklo22
            // 
            this.szklo22.BackColor = System.Drawing.Color.Transparent;
            this.szklo22.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo22.Location = new System.Drawing.Point(904, 702);
            this.szklo22.Name = "szklo22";
            this.szklo22.Size = new System.Drawing.Size(100, 40);
            this.szklo22.TabIndex = 213;
            this.szklo22.TabStop = false;
          
            this.szklo22.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo22_MouseMove);
            // 
            // szklo25
            // 
            this.szklo25.BackColor = System.Drawing.Color.Transparent;
            this.szklo25.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo25.Location = new System.Drawing.Point(904, 702);
            this.szklo25.Name = "szklo25";
            this.szklo25.Size = new System.Drawing.Size(100, 40);
            this.szklo25.TabIndex = 214;
            this.szklo25.TabStop = false;
        
            this.szklo25.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo25_MouseMove);
            // 
            // szklo28
            // 
            this.szklo28.BackColor = System.Drawing.Color.Transparent;
            this.szklo28.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo28.Location = new System.Drawing.Point(904, 702);
            this.szklo28.Name = "szklo28";
            this.szklo28.Size = new System.Drawing.Size(100, 40);
            this.szklo28.TabIndex = 215;
            this.szklo28.TabStop = false;
          
            this.szklo28.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo28_MouseMove);
            // 
            // szklo31
            // 
            this.szklo31.BackColor = System.Drawing.Color.Transparent;
            this.szklo31.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo31.Location = new System.Drawing.Point(904, 702);
            this.szklo31.Name = "szklo31";
            this.szklo31.Size = new System.Drawing.Size(100, 40);
            this.szklo31.TabIndex = 216;
            this.szklo31.TabStop = false;

            this.szklo31.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo31_MouseMove);
            // 
            // szklo34
            // 
            this.szklo34.BackColor = System.Drawing.Color.Transparent;
            this.szklo34.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo34.Location = new System.Drawing.Point(904, 702);
            this.szklo34.Name = "szklo34";
            this.szklo34.Size = new System.Drawing.Size(100, 40);
            this.szklo34.TabIndex = 217;
            this.szklo34.TabStop = false;
            
            this.szklo34.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo34_MouseMove);
            // 
            // szklo37
            // 
            this.szklo37.BackColor = System.Drawing.Color.Transparent;
            this.szklo37.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo37.Location = new System.Drawing.Point(904, 702);
            this.szklo37.Name = "szklo37";
            this.szklo37.Size = new System.Drawing.Size(100, 40);
            this.szklo37.TabIndex = 218;
            this.szklo37.TabStop = false;
         
            this.szklo37.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo37_MouseMove);
            // 
            // szklo40
            // 
            this.szklo40.BackColor = System.Drawing.Color.Transparent;
            this.szklo40.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo40.Location = new System.Drawing.Point(904, 702);
            this.szklo40.Name = "szklo40";
            this.szklo40.Size = new System.Drawing.Size(100, 40);
            this.szklo40.TabIndex = 219;
            this.szklo40.TabStop = false;
       
            this.szklo40.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo40_MouseMove);
            // 
            // szklo43
            // 
            this.szklo43.BackColor = System.Drawing.Color.Transparent;
            this.szklo43.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo43.Location = new System.Drawing.Point(904, 702);
            this.szklo43.Name = "szklo43";
            this.szklo43.Size = new System.Drawing.Size(100, 40);
            this.szklo43.TabIndex = 220;
            this.szklo43.TabStop = false;
           
            this.szklo43.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo43_MouseMove);
            // 
            // szklo46
            // 
            this.szklo46.BackColor = System.Drawing.Color.Transparent;
            this.szklo46.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo46.Location = new System.Drawing.Point(904, 702);
            this.szklo46.Name = "szklo46";
            this.szklo46.Size = new System.Drawing.Size(100, 40);
            this.szklo46.TabIndex = 221;
            this.szklo46.TabStop = false;
        
            this.szklo46.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo46_MouseMove);
            // 
            // szklo49
            // 
            this.szklo49.BackColor = System.Drawing.Color.Transparent;
            this.szklo49.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo49.Location = new System.Drawing.Point(904, 702);
            this.szklo49.Name = "szklo49";
            this.szklo49.Size = new System.Drawing.Size(100, 40);
            this.szklo49.TabIndex = 222;
            this.szklo49.TabStop = false;
        
            this.szklo49.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo49_MouseMove);
            // 
            // szklo52
            // 
            this.szklo52.BackColor = System.Drawing.Color.Transparent;
            this.szklo52.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo52.Location = new System.Drawing.Point(904, 702);
            this.szklo52.Name = "szklo52";
            this.szklo52.Size = new System.Drawing.Size(100, 40);
            this.szklo52.TabIndex = 223;
            this.szklo52.TabStop = false;
          
            this.szklo52.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo52_MouseMove);
            // 
            // szklo55
            // 
            this.szklo55.BackColor = System.Drawing.Color.Transparent;
            this.szklo55.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo55.Location = new System.Drawing.Point(904, 702);
            this.szklo55.Name = "szklo55";
            this.szklo55.Size = new System.Drawing.Size(100, 40);
            this.szklo55.TabIndex = 224;
            this.szklo55.TabStop = false;
          
            this.szklo55.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo55_MouseMove);
            // 
            // szklo58
            // 
            this.szklo58.BackColor = System.Drawing.Color.Transparent;
            this.szklo58.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo58.Location = new System.Drawing.Point(904, 702);
            this.szklo58.Name = "szklo58";
            this.szklo58.Size = new System.Drawing.Size(100, 40);
            this.szklo58.TabIndex = 225;
            this.szklo58.TabStop = false;
          
            this.szklo58.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo58_MouseMove);
            // 
            // szklo61
            // 
            this.szklo61.BackColor = System.Drawing.Color.Transparent;
            this.szklo61.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.beer_bottle_removebg_preview__1_;
            this.szklo61.Location = new System.Drawing.Point(904, 702);
            this.szklo61.Name = "szklo61";
            this.szklo61.Size = new System.Drawing.Size(100, 40);
            this.szklo61.TabIndex = 226;
            this.szklo61.TabStop = false;
          
            this.szklo61.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo61_MouseMove);
            // 
            // szklo5
            // 
            this.szklo5.BackColor = System.Drawing.Color.Transparent;
            this.szklo5.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo5.Location = new System.Drawing.Point(1054, 679);
            this.szklo5.Name = "szklo5";
            this.szklo5.Size = new System.Drawing.Size(43, 60);
            this.szklo5.TabIndex = 227;
            this.szklo5.TabStop = false;
          
            this.szklo5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo5_MouseMove);
            // 
            // szklo8
            // 
            this.szklo8.BackColor = System.Drawing.Color.Transparent;
            this.szklo8.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo8.Location = new System.Drawing.Point(1054, 679);
            this.szklo8.Name = "szklo8";
            this.szklo8.Size = new System.Drawing.Size(43, 60);
            this.szklo8.TabIndex = 228;
            this.szklo8.TabStop = false;
          
            this.szklo8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo8_MouseMove);
            // 
            // szklo11
            // 
            this.szklo11.BackColor = System.Drawing.Color.Transparent;
            this.szklo11.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo11.Location = new System.Drawing.Point(1054, 679);
            this.szklo11.Name = "szklo11";
            this.szklo11.Size = new System.Drawing.Size(43, 60);
            this.szklo11.TabIndex = 229;
            this.szklo11.TabStop = false;
           
            this.szklo11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo11_MouseMove);
            // 
            // szklo14
            // 
            this.szklo14.BackColor = System.Drawing.Color.Transparent;
            this.szklo14.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo14.Location = new System.Drawing.Point(1054, 679);
            this.szklo14.Name = "szklo14";
            this.szklo14.Size = new System.Drawing.Size(43, 60);
            this.szklo14.TabIndex = 230;
            this.szklo14.TabStop = false;
         
            this.szklo14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo14_MouseMove);
            // 
            // szklo17
            // 
            this.szklo17.BackColor = System.Drawing.Color.Transparent;
            this.szklo17.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo17.Location = new System.Drawing.Point(1054, 679);
            this.szklo17.Name = "szklo17";
            this.szklo17.Size = new System.Drawing.Size(43, 60);
            this.szklo17.TabIndex = 231;
            this.szklo17.TabStop = false;
           
            this.szklo17.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo17_MouseMove);
            // 
            // szklo20
            // 
            this.szklo20.BackColor = System.Drawing.Color.Transparent;
            this.szklo20.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo20.Location = new System.Drawing.Point(1054, 679);
            this.szklo20.Name = "szklo20";
            this.szklo20.Size = new System.Drawing.Size(43, 60);
            this.szklo20.TabIndex = 232;
            this.szklo20.TabStop = false;
        
            this.szklo20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo20_MouseMove);
            // 
            // szklo23
            // 
            this.szklo23.BackColor = System.Drawing.Color.Transparent;
            this.szklo23.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo23.Location = new System.Drawing.Point(1054, 679);
            this.szklo23.Name = "szklo23";
            this.szklo23.Size = new System.Drawing.Size(43, 60);
            this.szklo23.TabIndex = 233;
            this.szklo23.TabStop = false;
           
            this.szklo23.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo23_MouseMove);
            // 
            // szklo26
            // 
            this.szklo26.BackColor = System.Drawing.Color.Transparent;
            this.szklo26.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo26.Location = new System.Drawing.Point(1054, 679);
            this.szklo26.Name = "szklo26";
            this.szklo26.Size = new System.Drawing.Size(43, 60);
            this.szklo26.TabIndex = 234;
            this.szklo26.TabStop = false;
         
            this.szklo26.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo26_MouseMove);
            // 
            // szklo29
            // 
            this.szklo29.BackColor = System.Drawing.Color.Transparent;
            this.szklo29.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo29.Location = new System.Drawing.Point(1054, 679);
            this.szklo29.Name = "szklo29";
            this.szklo29.Size = new System.Drawing.Size(43, 60);
            this.szklo29.TabIndex = 235;
            this.szklo29.TabStop = false;
           
            this.szklo29.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo29_MouseMove);
            // 
            // szklo32
            // 
            this.szklo32.BackColor = System.Drawing.Color.Transparent;
            this.szklo32.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo32.Location = new System.Drawing.Point(1054, 679);
            this.szklo32.Name = "szklo32";
            this.szklo32.Size = new System.Drawing.Size(43, 60);
            this.szklo32.TabIndex = 236;
            this.szklo32.TabStop = false;
            
            this.szklo32.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo32_MouseMove);
            // 
            // szklo35
            // 
            this.szklo35.BackColor = System.Drawing.Color.Transparent;
            this.szklo35.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo35.Location = new System.Drawing.Point(1054, 679);
            this.szklo35.Name = "szklo35";
            this.szklo35.Size = new System.Drawing.Size(43, 60);
            this.szklo35.TabIndex = 237;
            this.szklo35.TabStop = false;
         
            this.szklo35.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo35_MouseMove);
            // 
            // szklo38
            // 
            this.szklo38.BackColor = System.Drawing.Color.Transparent;
            this.szklo38.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo38.Location = new System.Drawing.Point(1054, 679);
            this.szklo38.Name = "szklo38";
            this.szklo38.Size = new System.Drawing.Size(43, 60);
            this.szklo38.TabIndex = 238;
            this.szklo38.TabStop = false;
          
            this.szklo38.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo38_MouseMove);
            // 
            // szklo41
            // 
            this.szklo41.BackColor = System.Drawing.Color.Transparent;
            this.szklo41.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo41.Location = new System.Drawing.Point(1054, 679);
            this.szklo41.Name = "szklo41";
            this.szklo41.Size = new System.Drawing.Size(43, 60);
            this.szklo41.TabIndex = 239;
            this.szklo41.TabStop = false;
         
            this.szklo41.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo41_MouseMove);
            // 
            // szklo44
            // 
            this.szklo44.BackColor = System.Drawing.Color.Transparent;
            this.szklo44.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo44.Location = new System.Drawing.Point(1054, 679);
            this.szklo44.Name = "szklo44";
            this.szklo44.Size = new System.Drawing.Size(43, 60);
            this.szklo44.TabIndex = 240;
            this.szklo44.TabStop = false;
         
            this.szklo44.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo44_MouseMove);
            // 
            // szklo47
            // 
            this.szklo47.BackColor = System.Drawing.Color.Transparent;
            this.szklo47.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo47.Location = new System.Drawing.Point(1054, 679);
            this.szklo47.Name = "szklo47";
            this.szklo47.Size = new System.Drawing.Size(43, 60);
            this.szklo47.TabIndex = 241;
            this.szklo47.TabStop = false;
           
            this.szklo47.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo47_MouseMove);
            // 
            // szklo50
            // 
            this.szklo50.BackColor = System.Drawing.Color.Transparent;
            this.szklo50.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo50.Location = new System.Drawing.Point(1054, 679);
            this.szklo50.Name = "szklo50";
            this.szklo50.Size = new System.Drawing.Size(43, 60);
            this.szklo50.TabIndex = 242;
            this.szklo50.TabStop = false;
           
            this.szklo50.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo50_MouseMove);
            // 
            // szklo53
            // 
            this.szklo53.BackColor = System.Drawing.Color.Transparent;
            this.szklo53.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo53.Location = new System.Drawing.Point(1054, 679);
            this.szklo53.Name = "szklo53";
            this.szklo53.Size = new System.Drawing.Size(43, 60);
            this.szklo53.TabIndex = 243;
            this.szklo53.TabStop = false;
         
            this.szklo53.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo53_MouseMove);
            // 
            // szklo56
            // 
            this.szklo56.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo56.Location = new System.Drawing.Point(1054, 679);
            this.szklo56.Name = "szklo56";
            this.szklo56.Size = new System.Drawing.Size(43, 60);
            this.szklo56.TabIndex = 244;
            this.szklo56.TabStop = false;
          
            this.szklo56.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo56_MouseMove);
            // 
            // szklo59
            // 
            this.szklo59.BackColor = System.Drawing.Color.Transparent;
            this.szklo59.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo59.Location = new System.Drawing.Point(1054, 679);
            this.szklo59.Name = "szklo59";
            this.szklo59.Size = new System.Drawing.Size(43, 60);
            this.szklo59.TabIndex = 245;
            this.szklo59.TabStop = false;
           
            this.szklo59.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo59_MouseMove);
            // 
            // szklo62
            // 
            this.szklo62.BackColor = System.Drawing.Color.Transparent;
            this.szklo62.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.sloik__1__removebg_preview;
            this.szklo62.Location = new System.Drawing.Point(1054, 679);
            this.szklo62.Name = "szklo62";
            this.szklo62.Size = new System.Drawing.Size(43, 60);
            this.szklo62.TabIndex = 246;
            this.szklo62.TabStop = false;
          
            this.szklo62.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo62_MouseMove);
            // 
            // szklo6
            // 
            this.szklo6.BackColor = System.Drawing.Color.Transparent;
            this.szklo6.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo6.Location = new System.Drawing.Point(1141, 708);
            this.szklo6.Name = "szklo6";
            this.szklo6.Size = new System.Drawing.Size(83, 40);
            this.szklo6.TabIndex = 247;
            this.szklo6.TabStop = false;
           
            this.szklo6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo6_MouseMove);
            // 
            // szklo9
            // 
            this.szklo9.BackColor = System.Drawing.Color.Transparent;
            this.szklo9.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo9.Location = new System.Drawing.Point(1141, 708);
            this.szklo9.Name = "szklo9";
            this.szklo9.Size = new System.Drawing.Size(83, 40);
            this.szklo9.TabIndex = 248;
            this.szklo9.TabStop = false;
           
            this.szklo9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo9_MouseMove);
            // 
            // szklo12
            // 
            this.szklo12.BackColor = System.Drawing.Color.Transparent;
            this.szklo12.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo12.Location = new System.Drawing.Point(1141, 708);
            this.szklo12.Name = "szklo12";
            this.szklo12.Size = new System.Drawing.Size(83, 40);
            this.szklo12.TabIndex = 249;
            this.szklo12.TabStop = false;
         
            this.szklo12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo12_MouseMove);
            // 
            // szklo15
            // 
            this.szklo15.BackColor = System.Drawing.Color.Transparent;
            this.szklo15.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo15.Location = new System.Drawing.Point(1141, 708);
            this.szklo15.Name = "szklo15";
            this.szklo15.Size = new System.Drawing.Size(83, 40);
            this.szklo15.TabIndex = 250;
            this.szklo15.TabStop = false;
          
            this.szklo15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo15_MouseMove);
            // 
            // szklo18
            // 
            this.szklo18.BackColor = System.Drawing.Color.Transparent;
            this.szklo18.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo18.Location = new System.Drawing.Point(1141, 708);
            this.szklo18.Name = "szklo18";
            this.szklo18.Size = new System.Drawing.Size(83, 40);
            this.szklo18.TabIndex = 251;
            this.szklo18.TabStop = false;
          
            this.szklo18.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo18_MouseMove);
            // 
            // szklo21
            // 
            this.szklo21.BackColor = System.Drawing.Color.Transparent;
            this.szklo21.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo21.Location = new System.Drawing.Point(1141, 708);
            this.szklo21.Name = "szklo21";
            this.szklo21.Size = new System.Drawing.Size(83, 40);
            this.szklo21.TabIndex = 252;
            this.szklo21.TabStop = false;
          
            this.szklo21.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo21_MouseMove);
            // 
            // szklo24
            // 
            this.szklo24.BackColor = System.Drawing.Color.Transparent;
            this.szklo24.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo24.Location = new System.Drawing.Point(1141, 708);
            this.szklo24.Name = "szklo24";
            this.szklo24.Size = new System.Drawing.Size(83, 40);
            this.szklo24.TabIndex = 253;
            this.szklo24.TabStop = false;
          
            this.szklo24.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo24_MouseMove);
            // 
            // szklo27
            // 
            this.szklo27.BackColor = System.Drawing.Color.Transparent;
            this.szklo27.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo27.Location = new System.Drawing.Point(1141, 708);
            this.szklo27.Name = "szklo27";
            this.szklo27.Size = new System.Drawing.Size(83, 40);
            this.szklo27.TabIndex = 254;
            this.szklo27.TabStop = false;
      
            this.szklo27.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo27_MouseMove);
            // 
            // szklo30
            // 
            this.szklo30.BackColor = System.Drawing.Color.Transparent;
            this.szklo30.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo30.Location = new System.Drawing.Point(1141, 708);
            this.szklo30.Name = "szklo30";
            this.szklo30.Size = new System.Drawing.Size(83, 40);
            this.szklo30.TabIndex = 255;
            this.szklo30.TabStop = false;
         
            this.szklo30.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo30_MouseMove);
            // 
            // szklo33
            // 
            this.szklo33.BackColor = System.Drawing.Color.Transparent;
            this.szklo33.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo33.Location = new System.Drawing.Point(1141, 708);
            this.szklo33.Name = "szklo33";
            this.szklo33.Size = new System.Drawing.Size(83, 40);
            this.szklo33.TabIndex = 256;
            this.szklo33.TabStop = false;
           
            this.szklo33.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo33_MouseMove);
            // 
            // szklo36
            // 
            this.szklo36.BackColor = System.Drawing.Color.Transparent;
            this.szklo36.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo36.Location = new System.Drawing.Point(1141, 708);
            this.szklo36.Name = "szklo36";
            this.szklo36.Size = new System.Drawing.Size(83, 40);
            this.szklo36.TabIndex = 257;
            this.szklo36.TabStop = false;
           
            this.szklo36.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo36_MouseMove);
            // 
            // szklo39
            // 
            this.szklo39.BackColor = System.Drawing.Color.Transparent;
            this.szklo39.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo39.Location = new System.Drawing.Point(1141, 708);
            this.szklo39.Name = "szklo39";
            this.szklo39.Size = new System.Drawing.Size(83, 40);
            this.szklo39.TabIndex = 258;
            this.szklo39.TabStop = false;
          
            this.szklo39.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo39_MouseMove);
            // 
            // szklo42
            // 
            this.szklo42.BackColor = System.Drawing.Color.Transparent;
            this.szklo42.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo42.Location = new System.Drawing.Point(1141, 708);
            this.szklo42.Name = "szklo42";
            this.szklo42.Size = new System.Drawing.Size(83, 40);
            this.szklo42.TabIndex = 259;
            this.szklo42.TabStop = false;
           
            this.szklo42.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo42_MouseMove);
            // 
            // szklo45
            // 
            this.szklo45.BackColor = System.Drawing.Color.Transparent;
            this.szklo45.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo45.Location = new System.Drawing.Point(1141, 708);
            this.szklo45.Name = "szklo45";
            this.szklo45.Size = new System.Drawing.Size(83, 40);
            this.szklo45.TabIndex = 260;
            this.szklo45.TabStop = false;
          
            this.szklo45.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo45_MouseMove);
            // 
            // szklo48
            // 
            this.szklo48.BackColor = System.Drawing.Color.Transparent;
            this.szklo48.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo48.Location = new System.Drawing.Point(1141, 708);
            this.szklo48.Name = "szklo48";
            this.szklo48.Size = new System.Drawing.Size(83, 40);
            this.szklo48.TabIndex = 261;
            this.szklo48.TabStop = false;
          
            this.szklo48.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo48_MouseMove);
            // 
            // szklo51
            // 
            this.szklo51.BackColor = System.Drawing.Color.Transparent;
            this.szklo51.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo51.Location = new System.Drawing.Point(1141, 708);
            this.szklo51.Name = "szklo51";
            this.szklo51.Size = new System.Drawing.Size(83, 40);
            this.szklo51.TabIndex = 262;
            this.szklo51.TabStop = false;
          
            this.szklo51.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo51_MouseMove);
            // 
            // szklo54
            // 
            this.szklo54.BackColor = System.Drawing.Color.Transparent;
            this.szklo54.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo54.Location = new System.Drawing.Point(1141, 708);
            this.szklo54.Name = "szklo54";
            this.szklo54.Size = new System.Drawing.Size(80, 43);
            this.szklo54.TabIndex = 263;
            this.szklo54.TabStop = false;
         
            this.szklo54.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo54_MouseMove);
            // 
            // szklo57
            // 
            this.szklo57.BackColor = System.Drawing.Color.Transparent;
            this.szklo57.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo57.Location = new System.Drawing.Point(1141, 708);
            this.szklo57.Name = "szklo57";
            this.szklo57.Size = new System.Drawing.Size(80, 43);
            this.szklo57.TabIndex = 264;
            this.szklo57.TabStop = false;
          
            this.szklo57.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo57_MouseMove);
            // 
            // szklo60
            // 
            this.szklo60.BackColor = System.Drawing.Color.Transparent;
            this.szklo60.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo60.Location = new System.Drawing.Point(1141, 708);
            this.szklo60.Name = "szklo60";
            this.szklo60.Size = new System.Drawing.Size(80, 43);
            this.szklo60.TabIndex = 265;
            this.szklo60.TabStop = false;
          
            this.szklo60.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo60_MouseMove);
            // 
            // szklo63
            // 
            this.szklo63.BackColor = System.Drawing.Color.Transparent;
            this.szklo63.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.colkaaa_removebg_preview;
            this.szklo63.Location = new System.Drawing.Point(1141, 708);
            this.szklo63.Name = "szklo63";
            this.szklo63.Size = new System.Drawing.Size(83, 40);
            this.szklo63.TabIndex = 266;
            this.szklo63.TabStop = false;
           
            this.szklo63.MouseMove += new System.Windows.Forms.MouseEventHandler(this.szklo63_MouseMove);
            // 
            // papier4
            // 
            this.papier4.BackColor = System.Drawing.Color.Transparent;
            this.papier4.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier4.Location = new System.Drawing.Point(12, 679);
            this.papier4.Name = "papier4";
            this.papier4.Size = new System.Drawing.Size(60, 45);
            this.papier4.TabIndex = 267;
            this.papier4.TabStop = false;
          
            this.papier4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier4_MouseMove);
            // 
            // papier7
            // 
            this.papier7.BackColor = System.Drawing.Color.Transparent;
            this.papier7.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier7.Location = new System.Drawing.Point(12, 679);
            this.papier7.Name = "papier7";
            this.papier7.Size = new System.Drawing.Size(60, 45);
            this.papier7.TabIndex = 268;
            this.papier7.TabStop = false;
           
            this.papier7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier7_MouseMove);
            // 
            // papier10
            // 
            this.papier10.BackColor = System.Drawing.Color.Transparent;
            this.papier10.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier10.Location = new System.Drawing.Point(12, 679);
            this.papier10.Name = "papier10";
            this.papier10.Size = new System.Drawing.Size(60, 45);
            this.papier10.TabIndex = 269;
            this.papier10.TabStop = false;
         
            this.papier10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier10_MouseMove);
            // 
            // papier13
            // 
            this.papier13.BackColor = System.Drawing.Color.Transparent;
            this.papier13.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier13.Location = new System.Drawing.Point(12, 679);
            this.papier13.Name = "papier13";
            this.papier13.Size = new System.Drawing.Size(60, 45);
            this.papier13.TabIndex = 270;
            this.papier13.TabStop = false;
            
            this.papier13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier13_MouseMove);
            // 
            // papier16
            // 
            this.papier16.BackColor = System.Drawing.Color.Transparent;
            this.papier16.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier16.Location = new System.Drawing.Point(12, 679);
            this.papier16.Name = "papier16";
            this.papier16.Size = new System.Drawing.Size(60, 45);
            this.papier16.TabIndex = 271;
            this.papier16.TabStop = false;
          
            this.papier16.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier16_MouseMove);
            // 
            // papier19
            // 
            this.papier19.BackColor = System.Drawing.Color.Transparent;
            this.papier19.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier19.Location = new System.Drawing.Point(12, 679);
            this.papier19.Name = "papier19";
            this.papier19.Size = new System.Drawing.Size(60, 45);
            this.papier19.TabIndex = 272;
            this.papier19.TabStop = false;
           
            this.papier19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier19_MouseMove);
            // 
            // papier22
            // 
            this.papier22.BackColor = System.Drawing.Color.Transparent;
            this.papier22.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier22.Location = new System.Drawing.Point(12, 679);
            this.papier22.Name = "papier22";
            this.papier22.Size = new System.Drawing.Size(60, 45);
            this.papier22.TabIndex = 273;
            this.papier22.TabStop = false;
           
            this.papier22.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier22_MouseMove);
            // 
            // papier25
            // 
            this.papier25.BackColor = System.Drawing.Color.Transparent;
            this.papier25.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier25.Location = new System.Drawing.Point(12, 679);
            this.papier25.Name = "papier25";
            this.papier25.Size = new System.Drawing.Size(60, 45);
            this.papier25.TabIndex = 274;
            this.papier25.TabStop = false;
          
            this.papier25.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier25_MouseMove);
            // 
            // papier28
            // 
            this.papier28.BackColor = System.Drawing.Color.Transparent;
            this.papier28.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier28.Location = new System.Drawing.Point(12, 679);
            this.papier28.Name = "papier28";
            this.papier28.Size = new System.Drawing.Size(60, 45);
            this.papier28.TabIndex = 275;
            this.papier28.TabStop = false;
            
            this.papier28.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier28_MouseMove);
            // 
            // papier31
            // 
            this.papier31.BackColor = System.Drawing.Color.Transparent;
            this.papier31.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier31.Location = new System.Drawing.Point(12, 679);
            this.papier31.Name = "papier31";
            this.papier31.Size = new System.Drawing.Size(60, 45);
            this.papier31.TabIndex = 276;
            this.papier31.TabStop = false;
          
            this.papier31.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier31_MouseMove);
            // 
            // papier34
            // 
            this.papier34.BackColor = System.Drawing.Color.Transparent;
            this.papier34.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier34.Location = new System.Drawing.Point(12, 679);
            this.papier34.Name = "papier34";
            this.papier34.Size = new System.Drawing.Size(60, 45);
            this.papier34.TabIndex = 277;
            this.papier34.TabStop = false;
           
            this.papier34.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier34_MouseMove);
            // 
            // papier37
            // 
            this.papier37.BackColor = System.Drawing.Color.Transparent;
            this.papier37.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier37.Location = new System.Drawing.Point(12, 679);
            this.papier37.Name = "papier37";
            this.papier37.Size = new System.Drawing.Size(60, 45);
            this.papier37.TabIndex = 278;
            this.papier37.TabStop = false;
           
            this.papier37.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier37_MouseMove);
            // 
            // papier40
            // 
            this.papier40.BackColor = System.Drawing.Color.Transparent;
            this.papier40.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier40.Location = new System.Drawing.Point(12, 679);
            this.papier40.Name = "papier40";
            this.papier40.Size = new System.Drawing.Size(60, 45);
            this.papier40.TabIndex = 279;
            this.papier40.TabStop = false;
           
            this.papier40.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier40_MouseMove);
            // 
            // papier43
            // 
            this.papier43.BackColor = System.Drawing.Color.Transparent;
            this.papier43.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier43.Location = new System.Drawing.Point(12, 679);
            this.papier43.Name = "papier43";
            this.papier43.Size = new System.Drawing.Size(60, 45);
            this.papier43.TabIndex = 280;
            this.papier43.TabStop = false;
           
            this.papier43.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier43_MouseMove);
            // 
            // papier46
            // 
            this.papier46.BackColor = System.Drawing.Color.Transparent;
            this.papier46.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier46.Location = new System.Drawing.Point(12, 679);
            this.papier46.Name = "papier46";
            this.papier46.Size = new System.Drawing.Size(60, 45);
            this.papier46.TabIndex = 281;
            this.papier46.TabStop = false;
           
            this.papier46.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier46_MouseMove);
            // 
            // papier49
            // 
            this.papier49.BackColor = System.Drawing.Color.Transparent;
            this.papier49.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier49.Location = new System.Drawing.Point(12, 679);
            this.papier49.Name = "papier49";
            this.papier49.Size = new System.Drawing.Size(60, 45);
            this.papier49.TabIndex = 282;
            this.papier49.TabStop = false;
           
            this.papier49.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier49_MouseMove);
            // 
            // papier52
            // 
            this.papier52.BackColor = System.Drawing.Color.Transparent;
            this.papier52.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier52.Location = new System.Drawing.Point(12, 679);
            this.papier52.Name = "papier52";
            this.papier52.Size = new System.Drawing.Size(60, 45);
            this.papier52.TabIndex = 283;
            this.papier52.TabStop = false;
          
            this.papier52.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier52_MouseMove);
            // 
            // papier55
            // 
            this.papier55.BackColor = System.Drawing.Color.Transparent;
            this.papier55.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier55.Location = new System.Drawing.Point(12, 679);
            this.papier55.Name = "papier55";
            this.papier55.Size = new System.Drawing.Size(60, 45);
            this.papier55.TabIndex = 284;
            this.papier55.TabStop = false;
            
            this.papier55.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier55_MouseMove);
            // 
            // papier58
            // 
            this.papier58.BackColor = System.Drawing.Color.Transparent;
            this.papier58.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier58.Location = new System.Drawing.Point(12, 679);
            this.papier58.Name = "papier58";
            this.papier58.Size = new System.Drawing.Size(60, 45);
            this.papier58.TabIndex = 285;
            this.papier58.TabStop = false;
          
            this.papier58.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier58_MouseMove);
            // 
            // papier61
            // 
            this.papier61.BackColor = System.Drawing.Color.Transparent;
            this.papier61.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.zeszyt__1__removebg_preview;
            this.papier61.Location = new System.Drawing.Point(12, 679);
            this.papier61.Name = "papier61";
            this.papier61.Size = new System.Drawing.Size(60, 45);
            this.papier61.TabIndex = 286;
            this.papier61.TabStop = false;
            
            this.papier61.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier61_MouseMove);
            // 
            // papier5
            // 
            this.papier5.BackColor = System.Drawing.Color.Transparent;
            this.papier5.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier5.Location = new System.Drawing.Point(146, 672);
            this.papier5.Name = "papier5";
            this.papier5.Size = new System.Drawing.Size(51, 70);
            this.papier5.TabIndex = 287;
            this.papier5.TabStop = false;
           
            this.papier5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier5_MouseMove);
            // 
            // papier8
            // 
            this.papier8.BackColor = System.Drawing.Color.Transparent;
            this.papier8.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier8.Location = new System.Drawing.Point(146, 672);
            this.papier8.Name = "papier8";
            this.papier8.Size = new System.Drawing.Size(51, 70);
            this.papier8.TabIndex = 288;
            this.papier8.TabStop = false;
           
            this.papier8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier8_MouseMove);
            // 
            // papier11
            // 
            this.papier11.BackColor = System.Drawing.Color.Transparent;
            this.papier11.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier11.Location = new System.Drawing.Point(146, 672);
            this.papier11.Name = "papier11";
            this.papier11.Size = new System.Drawing.Size(51, 70);
            this.papier11.TabIndex = 289;
            this.papier11.TabStop = false;
           
            this.papier11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier11_MouseMove);
            // 
            // papier17
            // 
            this.papier17.BackColor = System.Drawing.Color.Transparent;
            this.papier17.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier17.Location = new System.Drawing.Point(146, 672);
            this.papier17.Name = "papier17";
            this.papier17.Size = new System.Drawing.Size(51, 70);
            this.papier17.TabIndex = 290;
            this.papier17.TabStop = false;
     
            this.papier17.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier17_MouseMove);
            // 
            // papier14
            // 
            this.papier14.BackColor = System.Drawing.Color.Transparent;
            this.papier14.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier14.Location = new System.Drawing.Point(146, 672);
            this.papier14.Name = "papier14";
            this.papier14.Size = new System.Drawing.Size(51, 70);
            this.papier14.TabIndex = 291;
            this.papier14.TabStop = false;
         
            this.papier14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier14_MouseMove);
            // 
            // papier20
            // 
            this.papier20.BackColor = System.Drawing.Color.Transparent;
            this.papier20.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier20.Location = new System.Drawing.Point(146, 672);
            this.papier20.Name = "papier20";
            this.papier20.Size = new System.Drawing.Size(51, 70);
            this.papier20.TabIndex = 292;
            this.papier20.TabStop = false;
          
            this.papier20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier20_MouseMove);
            // 
            // papier23
            // 
            this.papier23.BackColor = System.Drawing.Color.Transparent;
            this.papier23.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier23.Location = new System.Drawing.Point(146, 672);
            this.papier23.Name = "papier23";
            this.papier23.Size = new System.Drawing.Size(51, 70);
            this.papier23.TabIndex = 293;
            this.papier23.TabStop = false;
           
            this.papier23.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier23_MouseMove);
            // 
            // papier26
            // 
            this.papier26.BackColor = System.Drawing.Color.Transparent;
            this.papier26.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier26.Location = new System.Drawing.Point(146, 672);
            this.papier26.Name = "papier26";
            this.papier26.Size = new System.Drawing.Size(51, 70);
            this.papier26.TabIndex = 294;
            this.papier26.TabStop = false;
           
            this.papier26.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier26_MouseMove);
            // 
            // papier29
            // 
            this.papier29.BackColor = System.Drawing.Color.Transparent;
            this.papier29.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier29.Location = new System.Drawing.Point(146, 672);
            this.papier29.Name = "papier29";
            this.papier29.Size = new System.Drawing.Size(51, 70);
            this.papier29.TabIndex = 295;
            this.papier29.TabStop = false;
            
            this.papier29.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier29_MouseMove);
            // 
            // papier32
            // 
            this.papier32.BackColor = System.Drawing.Color.Transparent;
            this.papier32.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier32.Location = new System.Drawing.Point(146, 672);
            this.papier32.Name = "papier32";
            this.papier32.Size = new System.Drawing.Size(51, 70);
            this.papier32.TabIndex = 296;
            this.papier32.TabStop = false;
         
            this.papier32.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier32_MouseMove);
            // 
            // papier35
            // 
            this.papier35.BackColor = System.Drawing.Color.Transparent;
            this.papier35.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier35.Location = new System.Drawing.Point(146, 672);
            this.papier35.Name = "papier35";
            this.papier35.Size = new System.Drawing.Size(51, 70);
            this.papier35.TabIndex = 297;
            this.papier35.TabStop = false;
           
            this.papier35.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier35_MouseMove);
            // 
            // papier38
            // 
            this.papier38.BackColor = System.Drawing.Color.Transparent;
            this.papier38.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier38.Location = new System.Drawing.Point(146, 672);
            this.papier38.Name = "papier38";
            this.papier38.Size = new System.Drawing.Size(51, 70);
            this.papier38.TabIndex = 298;
            this.papier38.TabStop = false;
          
            this.papier38.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier38_MouseMove);
            // 
            // papier41
            // 
            this.papier41.BackColor = System.Drawing.Color.Transparent;
            this.papier41.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier41.Location = new System.Drawing.Point(146, 672);
            this.papier41.Name = "papier41";
            this.papier41.Size = new System.Drawing.Size(51, 70);
            this.papier41.TabIndex = 299;
            this.papier41.TabStop = false;
           
            this.papier41.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier41_MouseMove);
            // 
            // papier44
            // 
            this.papier44.BackColor = System.Drawing.Color.Transparent;
            this.papier44.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier44.Location = new System.Drawing.Point(146, 672);
            this.papier44.Name = "papier44";
            this.papier44.Size = new System.Drawing.Size(51, 70);
            this.papier44.TabIndex = 300;
            this.papier44.TabStop = false;
           
            this.papier44.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier44_MouseMove);
            // 
            // papier47
            // 
            this.papier47.BackColor = System.Drawing.Color.Transparent;
            this.papier47.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier47.Location = new System.Drawing.Point(146, 672);
            this.papier47.Name = "papier47";
            this.papier47.Size = new System.Drawing.Size(51, 70);
            this.papier47.TabIndex = 301;
            this.papier47.TabStop = false;
           
            this.papier47.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier47_MouseMove);
            // 
            // papier50
            // 
            this.papier50.BackColor = System.Drawing.Color.Transparent;
            this.papier50.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier50.Location = new System.Drawing.Point(146, 672);
            this.papier50.Name = "papier50";
            this.papier50.Size = new System.Drawing.Size(51, 70);
            this.papier50.TabIndex = 302;
            this.papier50.TabStop = false;
            
            this.papier50.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier50_MouseMove);
            // 
            // papier53
            // 
            this.papier53.BackColor = System.Drawing.Color.Transparent;
            this.papier53.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier53.Location = new System.Drawing.Point(146, 672);
            this.papier53.Name = "papier53";
            this.papier53.Size = new System.Drawing.Size(51, 70);
            this.papier53.TabIndex = 303;
            this.papier53.TabStop = false;
            
            this.papier53.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier53_MouseMove);
            // 
            // papier56
            // 
            this.papier56.BackColor = System.Drawing.Color.Transparent;
            this.papier56.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier56.Location = new System.Drawing.Point(146, 672);
            this.papier56.Name = "papier56";
            this.papier56.Size = new System.Drawing.Size(51, 70);
            this.papier56.TabIndex = 304;
            this.papier56.TabStop = false;
           
            this.papier56.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier56_MouseMove);
            // 
            // papier59
            // 
            this.papier59.BackColor = System.Drawing.Color.Transparent;
            this.papier59.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier59.Location = new System.Drawing.Point(146, 672);
            this.papier59.Name = "papier59";
            this.papier59.Size = new System.Drawing.Size(51, 70);
            this.papier59.TabIndex = 305;
            this.papier59.TabStop = false;
           
            this.papier59.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier59_MouseMove);
            // 
            // papier62
            // 
            this.papier62.BackColor = System.Drawing.Color.Transparent;
            this.papier62.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier62.Location = new System.Drawing.Point(146, 672);
            this.papier62.Name = "papier62";
            this.papier62.Size = new System.Drawing.Size(51, 70);
            this.papier62.TabIndex = 306;
            this.papier62.TabStop = false;
          ;
            this.papier62.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier62_MouseMove);
            // 
            // papier6
            // 
            this.papier6.BackColor = System.Drawing.Color.Transparent;
            this.papier6.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier6.Location = new System.Drawing.Point(251, 668);
            this.papier6.Name = "papier6";
            this.papier6.Size = new System.Drawing.Size(50, 73);
            this.papier6.TabIndex = 307;
            this.papier6.TabStop = false;
           
            this.papier6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier6_MouseMove);
            // 
            // papier9
            // 
            this.papier9.BackColor = System.Drawing.Color.Transparent;
            this.papier9.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier9.Location = new System.Drawing.Point(251, 668);
            this.papier9.Name = "papier9";
            this.papier9.Size = new System.Drawing.Size(50, 73);
            this.papier9.TabIndex = 308;
            this.papier9.TabStop = false;
           
            this.papier9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier9_MouseMove);
            // 
            // papier12
            // 
            this.papier12.BackColor = System.Drawing.Color.Transparent;
            this.papier12.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier12.Location = new System.Drawing.Point(251, 668);
            this.papier12.Name = "papier12";
            this.papier12.Size = new System.Drawing.Size(50, 73);
            this.papier12.TabIndex = 309;
            this.papier12.TabStop = false;
           
            this.papier12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier12_MouseMove);
            // 
            // papier15
            // 
            this.papier15.BackColor = System.Drawing.Color.Transparent;
            this.papier15.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier15.Location = new System.Drawing.Point(251, 668);
            this.papier15.Name = "papier15";
            this.papier15.Size = new System.Drawing.Size(50, 73);
            this.papier15.TabIndex = 310;
            this.papier15.TabStop = false;
            
            this.papier15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier15_MouseMove);
            // 
            // papier18
            // 
            this.papier18.BackColor = System.Drawing.Color.Transparent;
            this.papier18.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier18.Location = new System.Drawing.Point(251, 668);
            this.papier18.Name = "papier18";
            this.papier18.Size = new System.Drawing.Size(50, 73);
            this.papier18.TabIndex = 311;
            this.papier18.TabStop = false;
          
            this.papier18.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier18_MouseMove);
            // 
            // papier21
            // 
            this.papier21.BackColor = System.Drawing.Color.Transparent;
            this.papier21.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier21.Location = new System.Drawing.Point(251, 668);
            this.papier21.Name = "papier21";
            this.papier21.Size = new System.Drawing.Size(50, 73);
            this.papier21.TabIndex = 312;
            this.papier21.TabStop = false;
            
            this.papier21.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier21_MouseMove);
            // 
            // papier24
            // 
            this.papier24.BackColor = System.Drawing.Color.Transparent;
            this.papier24.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier24.Location = new System.Drawing.Point(251, 668);
            this.papier24.Name = "papier24";
            this.papier24.Size = new System.Drawing.Size(50, 73);
            this.papier24.TabIndex = 313;
            this.papier24.TabStop = false;
           
            this.papier24.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier24_MouseMove);
            // 
            // papier27
            // 
            this.papier27.BackColor = System.Drawing.Color.Transparent;
            this.papier27.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier27.Location = new System.Drawing.Point(251, 668);
            this.papier27.Name = "papier27";
            this.papier27.Size = new System.Drawing.Size(51, 70);
            this.papier27.TabIndex = 314;
            this.papier27.TabStop = false;
         
            this.papier27.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier27_MouseMove);
            // 
            // papier30
            // 
            this.papier30.BackColor = System.Drawing.Color.Transparent;
            this.papier30.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier30.Location = new System.Drawing.Point(251, 668);
            this.papier30.Name = "papier30";
            this.papier30.Size = new System.Drawing.Size(51, 70);
            this.papier30.TabIndex = 315;
            this.papier30.TabStop = false;
            
            this.papier30.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier30_MouseMove);
            // 
            // papier33
            // 
            this.papier33.BackColor = System.Drawing.Color.Transparent;
            this.papier33.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier33.Location = new System.Drawing.Point(251, 668);
            this.papier33.Name = "papier33";
            this.papier33.Size = new System.Drawing.Size(51, 70);
            this.papier33.TabIndex = 316;
            this.papier33.TabStop = false;
            
            this.papier33.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier33_MouseMove);
            // 
            // papier36
            // 
            this.papier36.BackColor = System.Drawing.Color.Transparent;
            this.papier36.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier36.Location = new System.Drawing.Point(251, 668);
            this.papier36.Name = "papier36";
            this.papier36.Size = new System.Drawing.Size(51, 70);
            this.papier36.TabIndex = 317;
            this.papier36.TabStop = false;
         
            this.papier36.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier36_MouseMove);
            // 
            // papier39
            // 
            this.papier39.BackColor = System.Drawing.Color.Transparent;
            this.papier39.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier39.Location = new System.Drawing.Point(251, 668);
            this.papier39.Name = "papier39";
            this.papier39.Size = new System.Drawing.Size(51, 70);
            this.papier39.TabIndex = 318;
            this.papier39.TabStop = false;
            
            this.papier39.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier39_MouseMove);
            // 
            // papier42
            // 
            this.papier42.BackColor = System.Drawing.Color.Transparent;
            this.papier42.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier42.Location = new System.Drawing.Point(251, 668);
            this.papier42.Name = "papier42";
            this.papier42.Size = new System.Drawing.Size(51, 70);
            this.papier42.TabIndex = 319;
            this.papier42.TabStop = false;
           
            this.papier42.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier42_MouseMove);
            // 
            // papier45
            // 
            this.papier45.BackColor = System.Drawing.Color.Transparent;
            this.papier45.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier45.Location = new System.Drawing.Point(251, 668);
            this.papier45.Name = "papier45";
            this.papier45.Size = new System.Drawing.Size(51, 70);
            this.papier45.TabIndex = 320;
            this.papier45.TabStop = false;
           
            this.papier45.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier45_MouseMove);
            // 
            // papier48
            // 
            this.papier48.BackColor = System.Drawing.Color.Transparent;
            this.papier48.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier48.Location = new System.Drawing.Point(251, 668);
            this.papier48.Name = "papier48";
            this.papier48.Size = new System.Drawing.Size(51, 70);
            this.papier48.TabIndex = 321;
            this.papier48.TabStop = false;
            
            this.papier48.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier48_MouseMove);
            // 
            // papier51
            // 
            this.papier51.BackColor = System.Drawing.Color.Transparent;
            this.papier51.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier51.Location = new System.Drawing.Point(251, 668);
            this.papier51.Name = "papier51";
            this.papier51.Size = new System.Drawing.Size(51, 70);
            this.papier51.TabIndex = 322;
            this.papier51.TabStop = false;
          
            this.papier51.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier51_MouseMove);
            // 
            // papier54
            // 
            this.papier54.BackColor = System.Drawing.Color.Transparent;
            this.papier54.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier54.Location = new System.Drawing.Point(251, 668);
            this.papier54.Name = "papier54";
            this.papier54.Size = new System.Drawing.Size(51, 70);
            this.papier54.TabIndex = 323;
            this.papier54.TabStop = false;
           
            this.papier54.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier54_MouseMove);
            // 
            // papier57
            // 
            this.papier57.BackColor = System.Drawing.Color.Transparent;
            this.papier57.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier57.Location = new System.Drawing.Point(251, 668);
            this.papier57.Name = "papier57";
            this.papier57.Size = new System.Drawing.Size(51, 70);
            this.papier57.TabIndex = 324;
            this.papier57.TabStop = false;
           
            this.papier57.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier57_MouseMove);
            // 
            // papier60
            // 
            this.papier60.BackColor = System.Drawing.Color.Transparent;
            this.papier60.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.torba__1__removebg_preview;
            this.papier60.Location = new System.Drawing.Point(251, 668);
            this.papier60.Name = "papier60";
            this.papier60.Size = new System.Drawing.Size(51, 70);
            this.papier60.TabIndex = 325;
            this.papier60.TabStop = false;
           
            this.papier60.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier60_MouseMove);
            // 
            // papier63
            // 
            this.papier63.BackColor = System.Drawing.Color.Transparent;
            this.papier63.BackgroundImage = global::JPWP_Projekt_sem_5.Properties.Resources.gazeta__1__removebg_preview;
            this.papier63.Location = new System.Drawing.Point(251, 668);
            this.papier63.Name = "papier63";
            this.papier63.Size = new System.Drawing.Size(51, 70);
            this.papier63.TabIndex = 326;
            this.papier63.TabStop = false;
           
            this.papier63.MouseMove += new System.Windows.Forms.MouseEventHandler(this.papier63_MouseMove);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1264, 841);
            this.Controls.Add(this.papier63);
            this.Controls.Add(this.papier60);
            this.Controls.Add(this.papier57);
            this.Controls.Add(this.papier54);
            this.Controls.Add(this.papier51);
            this.Controls.Add(this.papier48);
            this.Controls.Add(this.papier45);
            this.Controls.Add(this.papier42);
            this.Controls.Add(this.papier39);
            this.Controls.Add(this.papier36);
            this.Controls.Add(this.papier33);
            this.Controls.Add(this.papier30);
            this.Controls.Add(this.papier27);
            this.Controls.Add(this.papier24);
            this.Controls.Add(this.papier21);
            this.Controls.Add(this.papier18);
            this.Controls.Add(this.papier15);
            this.Controls.Add(this.papier12);
            this.Controls.Add(this.papier9);
            this.Controls.Add(this.papier6);
            this.Controls.Add(this.papier62);
            this.Controls.Add(this.papier59);
            this.Controls.Add(this.papier56);
            this.Controls.Add(this.papier53);
            this.Controls.Add(this.papier50);
            this.Controls.Add(this.papier47);
            this.Controls.Add(this.papier44);
            this.Controls.Add(this.papier41);
            this.Controls.Add(this.papier38);
            this.Controls.Add(this.papier35);
            this.Controls.Add(this.papier32);
            this.Controls.Add(this.papier29);
            this.Controls.Add(this.papier26);
            this.Controls.Add(this.papier23);
            this.Controls.Add(this.papier20);
            this.Controls.Add(this.papier14);
            this.Controls.Add(this.papier17);
            this.Controls.Add(this.papier11);
            this.Controls.Add(this.papier8);
            this.Controls.Add(this.papier5);
            this.Controls.Add(this.papier61);
            this.Controls.Add(this.papier58);
            this.Controls.Add(this.papier55);
            this.Controls.Add(this.papier52);
            this.Controls.Add(this.papier49);
            this.Controls.Add(this.papier46);
            this.Controls.Add(this.papier43);
            this.Controls.Add(this.papier40);
            this.Controls.Add(this.papier37);
            this.Controls.Add(this.papier34);
            this.Controls.Add(this.papier31);
            this.Controls.Add(this.papier28);
            this.Controls.Add(this.papier25);
            this.Controls.Add(this.papier22);
            this.Controls.Add(this.papier19);
            this.Controls.Add(this.papier16);
            this.Controls.Add(this.papier13);
            this.Controls.Add(this.papier10);
            this.Controls.Add(this.papier7);
            this.Controls.Add(this.papier4);
            this.Controls.Add(this.szklo63);
            this.Controls.Add(this.szklo60);
            this.Controls.Add(this.szklo57);
            this.Controls.Add(this.szklo54);
            this.Controls.Add(this.szklo51);
            this.Controls.Add(this.szklo48);
            this.Controls.Add(this.szklo45);
            this.Controls.Add(this.szklo42);
            this.Controls.Add(this.szklo39);
            this.Controls.Add(this.szklo36);
            this.Controls.Add(this.szklo33);
            this.Controls.Add(this.szklo30);
            this.Controls.Add(this.szklo27);
            this.Controls.Add(this.szklo24);
            this.Controls.Add(this.szklo21);
            this.Controls.Add(this.szklo18);
            this.Controls.Add(this.szklo15);
            this.Controls.Add(this.szklo12);
            this.Controls.Add(this.szklo9);
            this.Controls.Add(this.szklo6);
            this.Controls.Add(this.szklo62);
            this.Controls.Add(this.szklo59);
            this.Controls.Add(this.szklo56);
            this.Controls.Add(this.szklo53);
            this.Controls.Add(this.szklo50);
            this.Controls.Add(this.szklo47);
            this.Controls.Add(this.szklo44);
            this.Controls.Add(this.szklo41);
            this.Controls.Add(this.szklo38);
            this.Controls.Add(this.szklo35);
            this.Controls.Add(this.szklo32);
            this.Controls.Add(this.szklo29);
            this.Controls.Add(this.szklo26);
            this.Controls.Add(this.szklo23);
            this.Controls.Add(this.szklo20);
            this.Controls.Add(this.szklo17);
            this.Controls.Add(this.szklo14);
            this.Controls.Add(this.szklo11);
            this.Controls.Add(this.szklo8);
            this.Controls.Add(this.szklo5);
            this.Controls.Add(this.szklo61);
            this.Controls.Add(this.szklo58);
            this.Controls.Add(this.szklo55);
            this.Controls.Add(this.szklo52);
            this.Controls.Add(this.szklo49);
            this.Controls.Add(this.szklo46);
            this.Controls.Add(this.szklo43);
            this.Controls.Add(this.szklo40);
            this.Controls.Add(this.szklo37);
            this.Controls.Add(this.szklo34);
            this.Controls.Add(this.szklo31);
            this.Controls.Add(this.szklo28);
            this.Controls.Add(this.szklo25);
            this.Controls.Add(this.szklo22);
            this.Controls.Add(this.szklo19);
            this.Controls.Add(this.szklo16);
            this.Controls.Add(this.szklo13);
            this.Controls.Add(this.szklo10);
            this.Controls.Add(this.szklo7);
            this.Controls.Add(this.szklo4);
            this.Controls.Add(this.organiczne63);
            this.Controls.Add(this.organiczne60);
            this.Controls.Add(this.organiczne57);
            this.Controls.Add(this.organiczne54);
            this.Controls.Add(this.organiczne51);
            this.Controls.Add(this.organiczne48);
            this.Controls.Add(this.organiczne45);
            this.Controls.Add(this.organiczne42);
            this.Controls.Add(this.organiczne39);
            this.Controls.Add(this.organiczne36);
            this.Controls.Add(this.organiczne33);
            this.Controls.Add(this.organiczne30);
            this.Controls.Add(this.organiczne27);
            this.Controls.Add(this.organiczne24);
            this.Controls.Add(this.organiczne21);
            this.Controls.Add(this.organiczne18);
            this.Controls.Add(this.organiczne15);
            this.Controls.Add(this.organiczne12);
            this.Controls.Add(this.organiczne9);
            this.Controls.Add(this.organiczne6);
            this.Controls.Add(this.organiczne62);
            this.Controls.Add(this.organiczne59);
            this.Controls.Add(this.organiczne56);
            this.Controls.Add(this.organiczne53);
            this.Controls.Add(this.organiczne50);
            this.Controls.Add(this.organiczne47);
            this.Controls.Add(this.organiczne44);
            this.Controls.Add(this.organiczne41);
            this.Controls.Add(this.organiczne38);
            this.Controls.Add(this.organiczne35);
            this.Controls.Add(this.organiczne32);
            this.Controls.Add(this.organiczne29);
            this.Controls.Add(this.organiczne26);
            this.Controls.Add(this.organiczne23);
            this.Controls.Add(this.organiczne20);
            this.Controls.Add(this.organiczne17);
            this.Controls.Add(this.organiczne14);
            this.Controls.Add(this.organiczne11);
            this.Controls.Add(this.organiczne8);
            this.Controls.Add(this.organiczne5);
            this.Controls.Add(this.organiczne61);
            this.Controls.Add(this.organiczne58);
            this.Controls.Add(this.organiczne55);
            this.Controls.Add(this.organiczne52);
            this.Controls.Add(this.organiczne49);
            this.Controls.Add(this.organiczne46);
            this.Controls.Add(this.organiczne43);
            this.Controls.Add(this.organiczne40);
            this.Controls.Add(this.organiczne37);
            this.Controls.Add(this.organiczne34);
            this.Controls.Add(this.organiczne31);
            this.Controls.Add(this.organiczne28);
            this.Controls.Add(this.organiczne25);
            this.Controls.Add(this.organiczne22);
            this.Controls.Add(this.organiczne19);
            this.Controls.Add(this.organiczne16);
            this.Controls.Add(this.organiczne13);
            this.Controls.Add(this.organiczne10);
            this.Controls.Add(this.organiczne7);
            this.Controls.Add(this.organiczne4);
            this.Controls.Add(this.plastiki63);
            this.Controls.Add(this.plastiki60);
            this.Controls.Add(this.plastiki57);
            this.Controls.Add(this.plastiki54);
            this.Controls.Add(this.plastiki51);
            this.Controls.Add(this.plastiki48);
            this.Controls.Add(this.plastiki45);
            this.Controls.Add(this.plastiki42);
            this.Controls.Add(this.plastiki39);
            this.Controls.Add(this.plastiki36);
            this.Controls.Add(this.plastiki33);
            this.Controls.Add(this.plastiki30);
            this.Controls.Add(this.plastiki27);
            this.Controls.Add(this.plastiki24);
            this.Controls.Add(this.plastiki21);
            this.Controls.Add(this.plastiki18);
            this.Controls.Add(this.plastiki15);
            this.Controls.Add(this.plastiki12);
            this.Controls.Add(this.plastiki9);
            this.Controls.Add(this.plastiki6);
            this.Controls.Add(this.organiczne3);
            this.Controls.Add(this.organiczne2);
            this.Controls.Add(this.organiczne1);
            this.Controls.Add(this.papier3);
            this.Controls.Add(this.papier2);
            this.Controls.Add(this.papier1);
            this.Controls.Add(this.szklo3);
            this.Controls.Add(this.szklo2);
            this.Controls.Add(this.szklo1);
            this.Controls.Add(this.plastiki3);
            this.Controls.Add(this.plastiki1);
            this.Controls.Add(this.plastiki4);
            this.Controls.Add(this.plastiki7);
            this.Controls.Add(this.plastiki10);
            this.Controls.Add(this.plastiki13);
            this.Controls.Add(this.plastiki16);
            this.Controls.Add(this.plastiki19);
            this.Controls.Add(this.plastiki22);
            this.Controls.Add(this.plastiki25);
            this.Controls.Add(this.plastiki28);
            this.Controls.Add(this.plastiki31);
            this.Controls.Add(this.plastiki34);
            this.Controls.Add(this.plastiki37);
            this.Controls.Add(this.plastiki40);
            this.Controls.Add(this.plastiki43);
            this.Controls.Add(this.plastiki46);
            this.Controls.Add(this.plastiki49);
            this.Controls.Add(this.plastiki52);
            this.Controls.Add(this.plastiki55);
            this.Controls.Add(this.plastiki58);
            this.Controls.Add(this.plastiki61);
            this.Controls.Add(this.plastiki2);
            this.Controls.Add(this.plastiki5);
            this.Controls.Add(this.plastiki8);
            this.Controls.Add(this.plastiki11);
            this.Controls.Add(this.plastiki14);
            this.Controls.Add(this.plastiki17);
            this.Controls.Add(this.plastiki20);
            this.Controls.Add(this.plastiki23);
            this.Controls.Add(this.plastiki26);
            this.Controls.Add(this.plastiki29);
            this.Controls.Add(this.plastiki32);
            this.Controls.Add(this.plastiki35);
            this.Controls.Add(this.plastiki38);
            this.Controls.Add(this.plastiki41);
            this.Controls.Add(this.plastiki44);
            this.Controls.Add(this.plastiki47);
            this.Controls.Add(this.plastiki50);
            this.Controls.Add(this.plastiki53);
            this.Controls.Add(this.plastiki56);
            this.Controls.Add(this.plastiki59);
            this.Controls.Add(this.plastiki62);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plastiki63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.organiczne63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.szklo63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papier63)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label label1;


        private Plastiki plastiki1;
        private Plastiki plastiki2;
        private Plastiki plastiki3;
        private Plastiki plastiki4;
        private Plastiki plastiki7;
        private Plastiki plastiki10;
        private Plastiki plastiki13;
        private Plastiki plastiki16;
        private Plastiki plastiki19;
        private Plastiki plastiki22;
        private Plastiki plastiki25;
        private Plastiki plastiki28;
        private Plastiki plastiki31;
        private Plastiki plastiki34;
        private Plastiki plastiki37;
        private Plastiki plastiki40;
        private Plastiki plastiki43;
        private Plastiki plastiki46;
        private Plastiki plastiki49;
        private Plastiki plastiki52;
        private Plastiki plastiki55;
        private Plastiki plastiki58;
        private Plastiki plastiki61;
        
       


        private Plastiki plastiki5;
		private Plastiki plastiki8;
		private Plastiki plastiki11;
		private Plastiki plastiki14;
		private Plastiki plastiki17;
		private Plastiki plastiki20;
		private Plastiki plastiki23;
		private Plastiki plastiki26;
		private Plastiki plastiki29;
		private Plastiki plastiki32;
		private Plastiki plastiki35;
		private Plastiki plastiki38;
		private Plastiki plastiki41;
		private Plastiki plastiki44;
		private Plastiki plastiki47;
		private Plastiki plastiki50;
		private Plastiki plastiki53;
		private Plastiki plastiki56;
		private Plastiki plastiki59;
		private Plastiki plastiki62;
		

        
       
        private Szklo szklo1;
        private Szklo szklo2;
        private Szklo szklo3;
        private Papier papier1;
        private Papier papier2;
        private Papier papier3;
        private Organiczne organiczne1;
        private Organiczne organiczne2;
        private Organiczne organiczne3;
        private System.Windows.Forms.Timer GameTimer;
        private Plastiki plastiki6;
        private Plastiki plastiki9;
        private Plastiki plastiki12;
        private Plastiki plastiki15;
        private Plastiki plastiki18;
        private Plastiki plastiki21;
        private Plastiki plastiki24;
        private Plastiki plastiki27;
        private Plastiki plastiki30;
        private Plastiki plastiki33;
        private Plastiki plastiki36;
        private Plastiki plastiki39;
        private Plastiki plastiki42;
        private Plastiki plastiki45;
        private Plastiki plastiki48;
        private Plastiki plastiki51;
        private Plastiki plastiki54;
        private Plastiki plastiki57;
        private Plastiki plastiki60;
        private Plastiki plastiki63;
        private Organiczne organiczne4;
        private Organiczne organiczne7;
        private Organiczne organiczne10;
        private Organiczne organiczne13;
        private Organiczne organiczne16;
        private Organiczne organiczne19;
        private Organiczne organiczne22;
        private Organiczne organiczne25;
        private Organiczne organiczne28;
        private Organiczne organiczne31;
        private Organiczne organiczne34;
        private Organiczne organiczne37;
        private Organiczne organiczne40;
        private Organiczne organiczne43;
        private Organiczne organiczne46;
        private Organiczne organiczne49;
        private Organiczne organiczne52;
        private Organiczne organiczne55;
        private Organiczne organiczne58;
        private Organiczne organiczne61;
        private Organiczne organiczne5;
        private Organiczne organiczne8;
        private Organiczne organiczne11;
        private Organiczne organiczne14;
        private Organiczne organiczne17;
        private Organiczne organiczne20;
        private Organiczne organiczne23;
        private Organiczne organiczne26;
        private Organiczne organiczne29;
        private Organiczne organiczne32;
        private Organiczne organiczne35;
        private Organiczne organiczne38;
        private Organiczne organiczne41;
        private Organiczne organiczne44;
        private Organiczne organiczne47;
        private Organiczne organiczne50;
        private Organiczne organiczne53;
        private Organiczne organiczne56;
        private Organiczne organiczne59;
        private Organiczne organiczne62;
        private Organiczne organiczne6;
        private Organiczne organiczne9;
        private Organiczne organiczne12;
        private Organiczne organiczne15;
        private Organiczne organiczne18;
        private Organiczne organiczne21;
        private Organiczne organiczne24;
        private Organiczne organiczne27;
        private Organiczne organiczne30;
        private Organiczne organiczne33;
        private Organiczne organiczne36;
        private Organiczne organiczne39;
        private Organiczne organiczne42;
        private Organiczne organiczne45;
        private Organiczne organiczne48;
        private Organiczne organiczne51;
        private Organiczne organiczne54;
        private Organiczne organiczne57;
        private Organiczne organiczne60;
        private Organiczne organiczne63;
        private Szklo szklo4;
        private Szklo szklo7;
        private Szklo szklo10;
        private Szklo szklo13;
        private Szklo szklo16;
        private Szklo szklo19;
        private Szklo szklo22;
        private Szklo szklo25;
        private Szklo szklo28;
        private Szklo szklo31;
        private Szklo szklo34;
        private Szklo szklo37;
        private Szklo szklo40;
        private Szklo szklo43;
        private Szklo szklo46;
        private Szklo szklo49;
        private Szklo szklo52;
        private Szklo szklo55;
        private Szklo szklo58;
        private Szklo szklo61;
        private Szklo szklo5;
        private Szklo szklo8;
        private Szklo szklo11;
        private Szklo szklo14;
        private Szklo szklo17;
        private Szklo szklo20;
        private Szklo szklo23;
        private Szklo szklo26;
        private Szklo szklo29;
        private Szklo szklo32;
        private Szklo szklo35;
        private Szklo szklo38;
        private Szklo szklo41;
        private Szklo szklo44;
        private Szklo szklo47;
        private Szklo szklo50;
        private Szklo szklo53;
        private Szklo szklo56;
        private Szklo szklo59;
        private Szklo szklo62;
        private Szklo szklo6;
        private Szklo szklo9;
        private Szklo szklo12;
        private Szklo szklo15;
        private Szklo szklo18;
        private Szklo szklo21;
        private Szklo szklo24;
        private Szklo szklo27;
        private Szklo szklo30;
        private Szklo szklo33;
        private Szklo szklo36;
        private Szklo szklo39;
        private Szklo szklo42;
        private Szklo szklo45;
        private Szklo szklo48;
        private Szklo szklo51;
        private Szklo szklo54;
        private Szklo szklo57;
        private Szklo szklo60;
        private Szklo szklo63;
        private Papier papier4;
        private Papier papier7;
        private Papier papier10;
        private Papier papier13;
        private Papier papier16;
        private Papier papier19;
        private Papier papier22;
        private Papier papier25;
        private Papier papier28;
        private Papier papier31;
        private Papier papier34;
        private Papier papier37;
        private Papier papier40;
        private Papier papier43;
        private Papier papier46;
        private Papier papier49;
        private Papier papier52;
        private Papier papier55;
        private Papier papier58;
        private Papier papier61;
        private Papier papier5;
        private Papier papier8;
        private Papier papier11;
        private Papier papier17;
        private Papier papier14;
        private Papier papier20;
        private Papier papier23;
        private Papier papier26;
        private Papier papier29;
        private Papier papier32;
        private Papier papier35;
        private Papier papier38;
        private Papier papier41;
        private Papier papier44;
        private Papier papier47;
        private Papier papier50;
        private Papier papier53;
        private Papier papier56;
        private Papier papier59;
        private Papier papier62;
        private Papier papier6;
        private Papier papier9;
        private Papier papier12;
        private Papier papier15;
        private Papier papier18;
        private Papier papier21;
        private Papier papier24;
        private Papier papier27;
        private Papier papier30;
        private Papier papier33;
        private Papier papier36;
        private Papier papier39;
        private Papier papier42;
        private Papier papier45;
        private Papier papier48;
        private Papier papier51;
        private Papier papier54;
        private Papier papier57;
        private Papier papier60;
        private Papier papier63;
    }
}