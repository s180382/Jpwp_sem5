﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;


using System.Windows.Forms;
namespace JPWP_Projekt_sem_5
{
    public class Szklo : PictureBox
    {
        public Szklo(IContainer container_szklo)
        {
           container_szklo.Add(this);
        }

        Point point;

        protected override void OnMouseDown(MouseEventArgs e)
        {
            point = e.Location;
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - point.X;
                this.Top += e.Y - point.Y;

            }
            base.OnMouseMove(e);
        }
    }
}